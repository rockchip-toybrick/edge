package teaonly.rk.droidipcam;

public interface FloatViewCallBack {
        //public void setFloatView(int width, int height);
    public void stopSvr();
    }
