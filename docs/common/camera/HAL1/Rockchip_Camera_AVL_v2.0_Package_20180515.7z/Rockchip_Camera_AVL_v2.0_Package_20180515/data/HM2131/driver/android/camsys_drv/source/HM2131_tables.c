//HM2131_tables.c
/*****************************************************************************/
/*!
 *  \file        HM2131_tables.c \n
 *  \version     1.0 \n
 *  \author      Meinicke \n
 *  \brief       Image-sensor-specific tables and other
 *               constant values/structures for OV13850. \n
 *
 *  \revision    $Revision: 803 $ \n
 *               $Author: $ \n
 *               $Date: 2010-02-26 16:35:22 +0100 (Fr, 26 Feb 2010) $ \n
 *               $Id: OV13850_tables.c 803 2010-02-26 15:35:22Z  $ \n
 */
/*  This is an unpublished work, the copyright in which vests in Silicon Image
 *  GmbH. The information contained herein is the property of Silicon Image GmbH
 *  and is supplied without liability for errors or omissions. No part may be
 *  reproduced or used expect as authorized by contract or other written
 *  permission. Copyright(c) Silicon Image GmbH, 2009, all rights reserved.
 */
/*****************************************************************************/
/*
#include "stdinc.h"

#if( HM2131_DRIVER_USAGE == USE_CAM_DRV_EN )
*/


#include <ebase/types.h>
#include <ebase/trace.h>
#include <ebase/builtins.h>

#include <common/return_codes.h>

#include "isi.h"
#include "isi_iss.h"
#include "isi_priv.h"
#include "HM2131_MIPI_priv.h"


/*****************************************************************************
 * DEFINES
 *****************************************************************************/


/*****************************************************************************
 * GLOBALS
 *****************************************************************************/

// Image sensor register settings default values taken from data sheet OV13850_DS_1.1_SiliconImage.pdf.
// The settings may be altered by the code in IsiSetupSensor.

//2 lane
const IsiRegDescription_t Sensor_g_aRegDescription[] =
{
	
    //{0x0103,0x00, "eReadWrite",eReadWrite}, 

    {0x0304,0x2A, "eReadWrite",eReadWrite}, 

    {0x0305,0x0C, "eReadWrite",eReadWrite}, 

    {0x0307,0x55, "eReadWrite",eReadWrite}, 

    {0x0303,0x04, "eReadWrite",eReadWrite}, 

    {0x0309,0x00, "eReadWrite",eReadWrite}, 

    {0x030A,0x0A, "eReadWrite",eReadWrite}, 

    {0x030D,0x02, "eReadWrite",eReadWrite}, 

    {0x030F,0x14, "eReadWrite",eReadWrite}, 

    {0x5268,0x01, "eReadWrite",eReadWrite}, 

    {0x5264,0x24, "eReadWrite",eReadWrite}, 

    {0x5265,0x92, "eReadWrite",eReadWrite}, 

    {0x5266,0x23, "eReadWrite",eReadWrite}, 

    {0x5267,0x07, "eReadWrite",eReadWrite}, 

    {0x5269,0x02, "eReadWrite",eReadWrite}, 

    {0x0100,0x02, "eReadWrite",eReadWrite}, 

    {0x0100,0x02, "eReadWrite",eReadWrite}, 

    {0x0111,0x01, "eReadWrite",eReadWrite}, 

    {0x0112,0x0A, "eReadWrite",eReadWrite}, 

    {0x0113,0x0A, "eReadWrite",eReadWrite}, 

    {0x4B20,0x9E, "eReadWrite",eReadWrite}, //ce

    {0x4B18,0x12, "eReadWrite",eReadWrite}, 

    {0x4B02,0x05, "eReadWrite",eReadWrite}, 

    {0x4B43,0x07, "eReadWrite",eReadWrite}, 

    {0x4B05,0x1C, "eReadWrite",eReadWrite}, 

    {0x4B0E,0x00, "eReadWrite",eReadWrite}, 

    {0x4B0F,0x0D, "eReadWrite",eReadWrite}, 

    {0x4B06,0x06, "eReadWrite",eReadWrite}, 

    {0x4B39,0x0B, "eReadWrite",eReadWrite}, 

    {0x4B42,0x02, "eReadWrite",eReadWrite}, //07

    {0x4B03,0x0C, "eReadWrite",eReadWrite}, 

    {0x4B04,0x07, "eReadWrite",eReadWrite}, 

    {0x4B3A,0x0B, "eReadWrite",eReadWrite}, 

    {0x4B51,0x80, "eReadWrite",eReadWrite}, 

    {0x4B52,0x09, "eReadWrite",eReadWrite}, 

    //mDELAY(5, "eReadWrite",eReadWrite},                         

    {0x4B52,0xC9, "eReadWrite",eReadWrite}, 

    {0x4B57,0x07, "eReadWrite",eReadWrite}, 

    {0x4B68,0x6B, "eReadWrite",eReadWrite}, 

    {0x0350,0x37, "eReadWrite",eReadWrite}, 

    {0x5030,0x10, "eReadWrite",eReadWrite}, 

    {0x5032,0x02, "eReadWrite",eReadWrite}, 

    {0x5033,0xD1, "eReadWrite",eReadWrite}, 

    {0x5034,0x01, "eReadWrite",eReadWrite}, 

    {0x5035,0x67, "eReadWrite",eReadWrite}, 

    {0x5229,0x90, "eReadWrite",eReadWrite}, 

    {0x5061,0x00, "eReadWrite",eReadWrite}, 

    {0x5062,0x94, "eReadWrite",eReadWrite}, 

    {0x50F5,0x06, "eReadWrite",eReadWrite}, 

    {0x5230,0x00, "eReadWrite",eReadWrite}, 

    {0x526C,0x00, "eReadWrite",eReadWrite}, 

    {0x520B,0x41, "eReadWrite",eReadWrite}, 

    {0x5254,0x08, "eReadWrite",eReadWrite}, 

    {0x522B,0x00, "eReadWrite",eReadWrite}, 

    {0x4144,0x08, "eReadWrite",eReadWrite}, 

    {0x4148,0x03, "eReadWrite",eReadWrite}, 

    {0x4024,0x40, "eReadWrite",eReadWrite}, 

    {0x4B66,0x00, "eReadWrite",eReadWrite}, 

    {0x4B31,0x06, "eReadWrite",eReadWrite}, 

    {0x0202,0x04, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x0203,0x50, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x0340,0x0E, "eReadWrite",eReadWrite}, 

    {0x0341,0x82, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x0342,0x05, "eReadWrite",eReadWrite}, 

    {0x0343,0x00, "eReadWrite",eReadWrite}, 

    {0x034C,0x07, "eReadWrite",eReadWrite}, 

    {0x034D,0x80, "eReadWrite",eReadWrite}, 

    {0x034E,0x04, "eReadWrite",eReadWrite}, 

    {0x034F,0x38, "eReadWrite",eReadWrite}, 

    {0x0101,0x00, "eReadWrite",eReadWrite}, 

    {0x4020,0x10, "eReadWrite",eReadWrite}, 

    {0x50DD,0x01, "eReadWrite",eReadWrite}, //HiMOS_20160720

    {0x0350,0x37, "eReadWrite",eReadWrite}, 

    {0x4131,0x01, "eReadWrite",eReadWrite},	

    {0x4132,0x20, "eReadWrite",eReadWrite},	

    {0x5011,0x00, "eReadWrite",eReadWrite},	

    {0x5015,0x00, "eReadWrite",eReadWrite},	

    {0x501D,0x1C, "eReadWrite",eReadWrite},	

    {0x501E,0x00, "eReadWrite",eReadWrite},	

    {0x501F,0x20, "eReadWrite",eReadWrite},	

    {0x50D5,0xF0, "eReadWrite",eReadWrite},	

    {0x50D7,0x12, "eReadWrite",eReadWrite},	

    {0x50BB,0x14, "eReadWrite",eReadWrite},	

    {0x5040,0x07, "eReadWrite",eReadWrite},	

    {0x50B7,0x00, "eReadWrite",eReadWrite},	

    {0x50B8,0x10, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x50B9,0xFF, "eReadWrite",eReadWrite},	

    {0x50BA,0xFF, "eReadWrite",eReadWrite},	

    {0x5200,0x26, "eReadWrite",eReadWrite},	

    {0x5201,0x00, "eReadWrite",eReadWrite},	

    {0x5202,0x00, "eReadWrite",eReadWrite},	

    {0x5203,0x00, "eReadWrite",eReadWrite},	

    {0x5217,0x01, "eReadWrite",eReadWrite},	

    {0x5219,0x01, "eReadWrite",eReadWrite},  //HiMOS_20160919

    {0x5234,0x01, "eReadWrite",eReadWrite},	

    {0x526B,0x03, "eReadWrite",eReadWrite},	

    {0x4C00,0x00, "eReadWrite",eReadWrite},	

    {0x0310,0x00, "eReadWrite",eReadWrite},	

    {0x4B31,0x06, "eReadWrite",eReadWrite},	

    {0x4B3B,0x02, "eReadWrite",eReadWrite},	

    {0x4B44,0x0C, "eReadWrite",eReadWrite},	

    {0x4B45,0x01, "eReadWrite",eReadWrite},	

    {0x50A1,0x00, "eReadWrite",eReadWrite},	

    {0x50AA,0x2E, "eReadWrite",eReadWrite},	

    {0x50AC,0x44, "eReadWrite",eReadWrite},	

    {0x50AB,0x04, "eReadWrite",eReadWrite},	

    {0x50A0,0xB0, "eReadWrite",eReadWrite},	

    {0x50A2,0x1B, "eReadWrite",eReadWrite},	

    {0x50AF,0x00, "eReadWrite",eReadWrite},	

    {0x5208,0x55, "eReadWrite",eReadWrite},	

    {0x5209,0x03, "eReadWrite",eReadWrite},	

    {0x520D,0x40, "eReadWrite",eReadWrite},	

    {0x5214,0x18, "eReadWrite",eReadWrite},	

    {0x5215,0x03, "eReadWrite",eReadWrite},  //HiMOS_20160919

    {0x5216,0x00, "eReadWrite",eReadWrite},	

    {0x521A,0x10, "eReadWrite",eReadWrite},	

    {0x521B,0x24, "eReadWrite",eReadWrite},	

    {0x5232,0x04, "eReadWrite",eReadWrite},	

    {0x5233,0x03, "eReadWrite",eReadWrite},	

    {0x5106,0xF0, "eReadWrite",eReadWrite},	

    {0x510E,0xC1, "eReadWrite",eReadWrite},	

    {0x5166,0xF0, "eReadWrite",eReadWrite},	

    {0x516E,0xC1, "eReadWrite",eReadWrite},	

    {0x5196,0xF0, "eReadWrite",eReadWrite},	

    {0x519E,0xC1, "eReadWrite",eReadWrite},	

    {0x51C0,0x80, "eReadWrite",eReadWrite},	

    {0x51C4,0x80, "eReadWrite",eReadWrite},	

    {0x51C8,0x80, "eReadWrite",eReadWrite},	

    {0x51CC,0x80, "eReadWrite",eReadWrite},	

    {0x51D0,0x80, "eReadWrite",eReadWrite},	

    {0x51D4,0x80, "eReadWrite",eReadWrite},	

    {0x51D8,0x80, "eReadWrite",eReadWrite},	

    {0x51DC,0x80, "eReadWrite",eReadWrite},	

    {0x51C1,0x03, "eReadWrite",eReadWrite},	

    {0x51C5,0x13, "eReadWrite",eReadWrite},	

    {0x51C9,0x17, "eReadWrite",eReadWrite},	

    {0x51CD,0x27, "eReadWrite",eReadWrite},	

    {0x51D1,0x27, "eReadWrite",eReadWrite},	

    {0x51D5,0x2B, "eReadWrite",eReadWrite},	

    {0x51D9,0x2B, "eReadWrite",eReadWrite},	

    {0x51DD,0x2B, "eReadWrite",eReadWrite},	

    {0x51C2,0x4B, "eReadWrite",eReadWrite},	

    {0x51C6,0x4B, "eReadWrite",eReadWrite},	

    {0x51CA,0x4B, "eReadWrite",eReadWrite},	

    {0x51CE,0x49, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x51D2,0x49, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x51D6,0x49, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x51DA,0x49, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x51DE,0x49, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x51C3,0x10, "eReadWrite",eReadWrite},	

    {0x51C7,0x18, "eReadWrite",eReadWrite},  //HiMOS_20160919

    {0x51CB,0x10, "eReadWrite",eReadWrite},	

    {0x51CF,0x08, "eReadWrite",eReadWrite},	

    {0x51D3,0x08, "eReadWrite",eReadWrite},	

    {0x51D7,0x08, "eReadWrite",eReadWrite},	

    {0x51DB,0x08, "eReadWrite",eReadWrite},	

    {0x51DF,0x00, "eReadWrite",eReadWrite},	

    {0x51E0,0x94, "eReadWrite",eReadWrite},	

    {0x51E2,0x94, "eReadWrite",eReadWrite},	

    {0x51E4,0x94, "eReadWrite",eReadWrite},	

    {0x51E6,0x94, "eReadWrite",eReadWrite},	

    {0x51E1,0x00, "eReadWrite",eReadWrite},	

    {0x51E3,0x00, "eReadWrite",eReadWrite},	

    {0x51E5,0x00, "eReadWrite",eReadWrite},	

    {0x51E7,0x00, "eReadWrite",eReadWrite},	

    {0x5264,0x23, "eReadWrite",eReadWrite},	

    {0x5265,0x07, "eReadWrite",eReadWrite},	

    {0x5266,0x24, "eReadWrite",eReadWrite},	

    {0x5267,0x92, "eReadWrite",eReadWrite},	

    {0x5268,0x01, "eReadWrite",eReadWrite},	

    {0xBAA2,0xC0, "eReadWrite",eReadWrite}, 

    {0xBAA2,0x40, "eReadWrite",eReadWrite}, 

    {0xBA90,0x01, "eReadWrite",eReadWrite}, 

    {0xBA93,0x02, "eReadWrite",eReadWrite}, 

    {0x3110,0x0B, "eReadWrite",eReadWrite}, 

    {0x373E,0x8A, "eReadWrite",eReadWrite}, 

    {0x373F,0x8A, "eReadWrite",eReadWrite}, 

    {0x3701,0x05, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x3709,0x05, "eReadWrite",eReadWrite},  //HiMOS_20160720

  	{0x3703,0x04, "eReadWrite",eReadWrite},  //HiMOS_20160720 

    {0x370B,0x04, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x3713,0x00, "eReadWrite",eReadWrite}, 

    {0x3717,0x00, "eReadWrite",eReadWrite}, 

    {0x5043,0x01, "eReadWrite",eReadWrite}, 

    //{0x501D,0x1C, "eReadWrite",eReadWrite}, //for BLC hunting   //HiMOS_20160720 

    {0x5040,0x05, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x5044,0x07, "eReadWrite",eReadWrite},	

    {0x6000,0x0F, "eReadWrite",eReadWrite},	

    {0x6001,0xFF, "eReadWrite",eReadWrite},	

    {0x6002,0x1F, "eReadWrite",eReadWrite},	

    {0x6003,0xFF, "eReadWrite",eReadWrite},	

    {0x6004,0xC2, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x6005,0x00, "eReadWrite",eReadWrite},	

    {0x6006,0x00, "eReadWrite",eReadWrite},	

    {0x6007,0x00, "eReadWrite",eReadWrite},	

    {0x6008,0x00, "eReadWrite",eReadWrite},	

    {0x6009,0x00, "eReadWrite",eReadWrite},	

    {0x600A,0x00, "eReadWrite",eReadWrite},	

    {0x600B,0x00, "eReadWrite",eReadWrite},	

    {0x600C,0x00, "eReadWrite",eReadWrite},	

    {0x600D,0x20, "eReadWrite",eReadWrite},	

    {0x600E,0x00, "eReadWrite",eReadWrite},	

    {0x600F,0xA1, "eReadWrite",eReadWrite},	

    {0x6010,0x01, "eReadWrite",eReadWrite},	

    {0x6011,0x00, "eReadWrite",eReadWrite},	

    {0x6012,0x06, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x6013,0x00, "eReadWrite",eReadWrite},	

    {0x6014,0x0B, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x6015,0x00, "eReadWrite",eReadWrite},	

    {0x6016,0x14, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x6017,0x00, "eReadWrite",eReadWrite},	

    {0x6018,0x25, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x6019,0x00, "eReadWrite",eReadWrite},	

    {0x601A,0x43, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x601B,0x00, "eReadWrite",eReadWrite},  //HiMOS_20160720

    {0x601C,0x82, "eReadWrite",eReadWrite},  //HiMOS_20160720 

    //{0x0101,0x03, "eReadWrite",eReadWrite},	 
    //{0x0000,0x00, "eReadWrite",eReadWrite}, 

    {0x0104,0x01, "eReadWrite",eReadWrite}, 

    {0x0104,0x00, "eReadWrite",eReadWrite}, 

    //{0x0100,0x03, "eReadWrite",eReadWrite},		 

	  {0x0000 ,0x00, "eReadWrite",eTableEnd}
	  
	  /*
	  
	   // Initial
    //---------------------------------------------------
    // soft reset
    {0x0103, 0x00, "0x0100",eReadWrite}, //soft reset
    //---------------------------------------------------


    //---------------------------------------------------
    // PLL ( 1080p60fps,RAW10,MIPI: pclk=42.5MHz, pkt_clk=60MHz )
    //---------------------------------------------------
    // adclk
    {0x0304, 0x2A, "0x0100",eReadWrite}, //[5]=pll_en_d, [4]=pll_bypass_d, [3:2]=RP_ctrl[1:0], [1:0]=CP_ctrl[1:0]
    {0x0305, 0x0C, "0x0100",eReadWrite}, //pre_div[4:0] 0C=> f_base=2MHz
    {0x0307, 0x55, "0x0100",eReadWrite}, //post_div[7:0] 55=> vco=340MHz
    {0x0303, 0x04, "0x0100",eReadWrite}, //vt_sys[4:0] 04=> adclk=vco, sys_clk=vco/8// 00=> adclk=vco, sys_clk=vco/4
    // mipi_clk
    {0x0309, 0x00, "0x0100",eReadWrite}, //MIPI_CP/CN=vco/n(full-size), =vco/2n(bin2 or sub2 mode)
    {0x030A, 0x0A, "0x0100",eReadWrite}, //mipi_pll3_d[4:0] [5,1,0]=CP_ctrl[2:0], [3:2]=RP_ctrl[1:0] [4]:bypass
    {0x030D, 0x02, "0x0100",eReadWrite}, //pre_div[4:0] 02=> f_base=12MHz
    {0x030F, 0x14, "0x0100",eReadWrite}, //post_div[6:0] 14=> mipi_clk=240MHz
    // SSCG
    {0x5268, 0x01, "0x0100",eReadWrite}, //SSCG_disable, 1=disable 
    {0x5264, 0x24, "0x0100",eReadWrite}, //SSCG upper HB(fixed value)
    {0x5265, 0x92, "0x0100",eReadWrite}, //SSCG upper LB(fixed value)
    {0x5266, 0x23, "0x0100",eReadWrite}, //SSCG lower HB 23,07,02~0.4438%
    {0x5267, 0x07, "0x0100",eReadWrite}, //SSCG lower LB
    {0x5269, 0x02, "0x0100",eReadWrite}, //SSCG jump step
    //activate PLL
    {0x0100, 0x02, "0x0100",eReadWrite}, //mode_select: 0h=stby, 2h=pwr_up, 1h/3h=streaming.
    
    
    //---------------------------------------------------
    // B9 mipi-tx pseudo-buffer setting
    //---------------------------------------------------
    
    {0x0100, 0x02, "0x0100",eReadWrite}, //mode_select: 0h=stby, 2h=pwr_up, 1h/3h=streaming.
    {0x0111, 0x01, "0x0100",eReadWrite}, //B9: 1'b0:1lane, 1'b1:2lane 
    {0x0112, 0x0A, "0x0100",eReadWrite}, //DataFormat : 0x08:RAW8, 0x0A:RAW10, 0x0C:RAW12 
    {0x0113, 0x0A, "0x0100",eReadWrite}, //DataFormat : 0x08:RAW8, 0x0A:RAW10, 0x0C:RAW12 
    {0x4B20, 0xCE, "0x0100",eReadWrite}, //clock always on(9E) / clock always on while sending packet(BE)
    {0x4B18, 0x12, "0x0100",eReadWrite}, //[7:0] FULL_TRIGGER_TIME
               
    {0x4B02, 0x05, "0x0100",eReadWrite}, //TLPX
    {0x4B43, 0x07, "0x0100",eReadWrite}, //CLK_PREPARE
    {0x4B05, 0x1C, "0x0100",eReadWrite}, //CLK_ZERO
    {0x4B0E, 0x00, "0x0100",eReadWrite}, //clk_front_porch
    {0x4B0F, 0x0D, "0x0100",eReadWrite}, //CLK_BACK_PORCH
    {0x4B06, 0x06, "0x0100",eReadWrite}, //CLK_TRAIL
    {0x4B39, 0x0B, "0x0100",eReadWrite}, //CLK_EXIT
    {0x4B42, 0x07, "0x0100",eReadWrite}, //HS_PREPARE
    {0x4B03, 0x0C, "0x0100",eReadWrite}, //HS_ZERO
    {0x4B04, 0x07, "0x0100",eReadWrite}, //HS_TRAIL
    {0x4B3A, 0x0B, "0x0100",eReadWrite}, //HS_EXIT
               
    {0x4B51, 0x80, "0x0100",eReadWrite}, //
    {0x4B52, 0x09, "0x0100",eReadWrite}, //
    
    {0x0000, 0x0A, "0x0100",eDelay},              //
    {0x4B52, 0xC9, "0x0100",eReadWrite}, //
    {0x4B57, 0x07, "0x0100",eReadWrite}, //
    {0x4B68, 0x6B, "0x0100",eReadWrite}, //[7:6]:VC[1:0], [5:0]:DT[5:0]
    
    //---------------------------------------------------
    // B9 Setting (ID:24)
    //---------------------------------------------------
    {0x0350, 0x37, "0x0100",eReadWrite}, //[4]d_gain enable, [5]analog d_gain enable 
               
    {0x5030, 0x10, "0x0100",eReadWrite}, //[0]:Stagger HDR enable
    {0x5032, 0x02, "0x0100",eReadWrite}, //HDR INTG Long(HB)
    {0x5033, 0xD1, "0x0100",eReadWrite}, //HDR INTG Long(LB)
    {0x5034, 0x01, "0x0100",eReadWrite}, //HDR INTG Short(HB)
    {0x5035, 0x67, "0x0100",eReadWrite}, //HDR INTG Short(LB)
               
    {0x5229, 0x90, "0x0100",eReadWrite}, //[0]oe_d
    {0x5061, 0x00, "0x0100",eReadWrite}, //Parallel out [0] : 1/0 -> on/off, [1]:Long/Short : 1/0 ,[2]:parallel clock gating: 1: gating 0:no gating
    {0x5062, 0x94, "0x0100",eReadWrite}, //
    {0x50F5, 0x06, "0x0100",eReadWrite}, //
               
    {0x5230, 0x00, "0x0100",eReadWrite}, //[1] 12bit mode enable
    {0x526C, 0x00, "0x0100",eReadWrite}, //[1:0]TDM_sel_d<1:0> 00/01/10/11=3/4/5/6 bit TDM.
    {0x520B, 0x41, "0x0100",eReadWrite}, //[4]adc12b_en_d, 12bit=>0x51, 10bit=>0x41
    // [0]ramp_sample_en_d [1]dacout_mode_en_d [2]rgain_float_en_d [3]rampout_byp_en_d [4]adc12b_en_d [5]cai_sample_en_d [6]bl_clamp_en_d [7]bl_float_en_d
    // Change 0x0112, 0x0113, 0x5230,  0x526C, 520B, 0x50AD, 0x50AE together for RAW10<-->RAW12.
    // Also change 20 100 for RAW10<-->RAW12 (HUB System)
    
    {0x5254, 0x08, "0x0100",eReadWrite}, //Staggered HDR INTG-S Delay(LB)
    {0x522B, 0x00, "0x0100",eReadWrite}, //NonHDR set to 0x00, HDR set to 0x78
               
    {0x4144, 0x08, "0x0100",eReadWrite}, //
    {0x4148, 0x03, "0x0100",eReadWrite}, //
    {0x4024, 0x40, "0x0100",eReadWrite}, //[6]:MIPI enable
    {0x4B66, 0x00, "0x0100",eReadWrite}, //
    {0x4B31, 0x06, "0x0100",eReadWrite}, //[3]Inverse Digital PKT Clock 0 : PKT = PKT 1:PKT = PKT 
    
    //---------------------------------------------------
    // Frame Length & Row Time
    //---------------------------------------------------
    // For full size
    // Frame length >= 1102
    // Frame length >= (INTG+2)
    
    //INTG
    {0x0202, 0x04, "0x0100",eReadWrite}, //
    {0x0203, 0x50, "0x0100",eReadWrite}, //
    
    //Frame Length
    {0x0340, 0x04, "0x0100",eReadWrite}, //frame length(HB)
    {0x0341, 0x52, "0x0100",eReadWrite}, //frame length(LB)
    //{0x0340, 0x09, "0x0100",eReadWrite}, //frame length(HB)
    //{0x0341, 0xAE, "0x0100",eReadWrite}, //frame length(LB)
    
    //Row Time 
    {0x0342, 0x05, "0x0100",eReadWrite}, //line length(HB)
    {0x0343, 0x00, "0x0100",eReadWrite}, //line length(LB)
    
    //Window Size
    {0x034C, 0x07, "0x0100",eReadWrite}, //x_output_size(HB)
    {0x034D, 0x88, "0x0100",eReadWrite}, //x_output_size(LB)
    {0x034E, 0x04, "0x0100",eReadWrite}, //y_output_size(HB)
    {0x034F, 0x40, "0x0100",eReadWrite}, //y_output_size(LB)
    
    {0x0101, 0x00, "0x0100",eReadWrite}, //[0]=mirror, [1]=flip
    {0x4020, 0x10, "0x0100",eReadWrite}, //[4]: 0:pclk=pclk, 1:pclk=~pclk.
    
    //---------------------------------------------------
    // Analog setting
    //---------------------------------------------------
    
    {0x50DD, 0x01, "0x0100",eReadWrite}, //GAIN STRETEGY: 0=SMIA, 1=HII
               
    {0x0350, 0x37, "0x0100",eReadWrite}, //[4]d_gain enable, [5]analog d_gain enable // enable digital gain(including digital a_gain) overwrite main setting.
    {0x4131, 0x01, "0x0100",eReadWrite}, //enable BLI for gain block
    {0x4132, 0x20, "0x0100",eReadWrite}, //BLI target(need the same as BLC target)
    {0x5011, 0x00, "0x0100",eReadWrite}, //BLC manual offset HB, [5]=0:add, [5]=1:subtract
    {0x5015, 0x00, "0x0100",eReadWrite}, //[3]: Black/ Test row output enable
    {0x501D, 0x1C, "0x0100",eReadWrite}, //enable BLC dithering// BLC by color. enable BLC hysteresis(check).
    {0x501E, 0x00, "0x0100",eReadWrite}, //BLC target(HB)
    {0x501F, 0x20, "0x0100",eReadWrite}, //BLC target(LB)
    
    // VRNP ON/OFF by INT
    {0x50D5, 0xF0, "0x0100",eReadWrite}, //-ve pump auto off by INT for G1/G2 balace and improve SNR (Simon) [4]:NEGPUMP maskout bad frame 1: don't maskout
    {0x50D7, 0x12, "0x0100",eReadWrite}, //MUX_NEGPUMP_OFF = NEGPUMP_Extend_off(0x50D7*16)
    {0x50BB, 0x14, "0x0100",eReadWrite}, //MUX_NEGPUMP_ON = NEGPUMP_Extend_on(0x50BB*16)
    
    //TS
    {0x5040, 0x07, "0x0100",eReadWrite}, //[0]:ts_en_d
    //0x5047 is TS output value.
    
    
    //Analog
    
    //{0x4004, 0x03, "0x0100",eReadWrite}, //PLL_Tlock_CNT(HB)
    //{0x4005, 0x00, "0x0100",eReadWrite}, //PLL_Tlock_CNT(HB)
    
    {0x50B7, 0x00, "0x0100",eReadWrite}, //DIN_OFFSET(HB)
    {0x50B8, 0x10, "0x0100",eReadWrite}, //DIN_OFFSET(LB)
    {0x50B9, 0xFF, "0x0100",eReadWrite}, //RST_THRESHOLD(HB), FFFF=no clamp
    {0x50BA, 0xFF, "0x0100",eReadWrite}, //RST_THRESHOLD(LB), FFFF=no clamp
               
    {0x5200, 0x26, "0x0100",eReadWrite}, //atest_reserve_left_1_d, [1:0]: rampbuf_bias_sel_d<3:2>, [2]=n_lowpwr_en_d(VRPP)
    {0x5201, 0x00, "0x0100",eReadWrite}, //atest_reserve_left_2_d,
    {0x5202, 0x00, "0x0100",eReadWrite}, //atest_reserve_right_1_d,
    {0x5203, 0x00, "0x0100",eReadWrite}, //atest_reserve_right_2_d,
               
    {0x5217, 0x01, "0x0100",eReadWrite}, //[1:0]:avdd16_sel_d<1:0>, [2]:avdd16_ldo_pd_d
    {0x5219, 0x01, "0x0100",eReadWrite}, //[1:0]: vrst_low_sel_d_d<1:0>  improve banding
               
    {0x5234, 0x01, "0x0100",eReadWrite}, //[7:0] vrpp_samle_d pulse width
    
    // ldo setting
    {0x526B, 0x03, "0x0100",eReadWrite}, //[0] LDO_T_en_d, [1] LDO_L_en_d
    {0x4C00, 0x00, "0x0100",eReadWrite}, //[1] : ext_ldo_en
    //{0x526B, 0x00, "0x0100",eReadWrite}, //[0] LDO_T_en_d, [1] LDO_L_en_d (for advdd=2.0V work around)
    //{0x4C00, 0x02, "0x0100",eReadWrite}, //[1] : ext_ldo_en (for advdd=2.0V work around)
    // for advdd=2.0V work around--> change 526B, 4C00, 4B3B
    
    // MIPI analog setting
    
    {0x0310, 0x00, "0x0100",eReadWrite}, //[2]=polar_det_enb_d, [1]=avdd16_dvdd_en_d,  [0]: 1:bypass MIPI LDO , 0: enable MIPI LDO
    {0x4B31, 0x06, "0x0100",eReadWrite}, //[1]: DATA_LAT_PHASE_SEL_D(PHASE_SEL, MIPI1[7]),[3]Inverse Digital PKT Clock 0 : PKT = PKT 1:PKT = PKT 
               
    {0x4B3B, 0x02, "0x0100",eReadWrite}, //[7]: NC   
               
    {0x4B44, 0x0C, "0x0100",eReadWrite}, //mipi duty adjust
    {0x4B45, 0x01, "0x0100",eReadWrite}, //mipi skew adjust according to test result.
    
    //{0x51D1, 0x20, "0x0100",eReadWrite}, //[3:2]ca_bias_sel(B pixel:dark fluorescent lamp issue) Simon
    //{0x51D5, 0x20, "0x0100",eReadWrite}, //[3:2]ca_bias_sel(B pixel:dark fluorescent lamp issue) Simon
    //{0x51D9, 0x20, "0x0100",eReadWrite}, //[3:2]ca_bias_sel(B pixel:dark fluorescent lamp issue) Simon
    //{0x51DD, 0x20, "0x0100",eReadWrite}, //[3:2]ca_bias_sel(B pixel:dark fluorescent lamp issue?) Simon
    
    
    // Updated 20160119 //
    
    {0x50A1, 0x00, "0x0100",eReadWrite}, //row_tg_cds_r_reg[7:4] row_tg_rst_f_reg[3:0]
    {0x50AA, 0x2E, "0x0100",eReadWrite}, //cds_rst_f_reg[7:4] ca_rst_f_reg[3:0] 
    {0x50AC, 0x44, "0x0100",eReadWrite}, //(0119 RFPN) //[7:4]ramp_start_r2_reg<3:0> [3:0]ramp_start_r1_reg<3:0>
    {0x50AB, 0x04, "0x0100",eReadWrite}, //ramp_rst_f_reg[7:4] comp_rst_f_reg[3:0]
    {0x50A0, 0xB0, "0x0100",eReadWrite}, //(0119 RFPN) //sf_bias_en_r_reg[7:4] rt_rst_f_reg_buf1[3:0]
    {0x50A2, 0x1B, "0x0100",eReadWrite}, //ramp_offset_en_f2_reg[7:0]  improve banding 
    {0x50AF, 0x00, "0x0100",eReadWrite}, //[7:4]row_tg_cds_f_reg,<3:0> [3:0]ramp_offset_en_f1_reg<3:0>
    {0x5208, 0x55, "0x0100",eReadWrite}, //[2:0]clamp_stg1_d [5:3]clamp_stg2_d
    {0x5209, 0x03, "0x0100",eReadWrite}, //[1:0]sf_bias_d [3:2]sf_biasn_d     0F-> 03 reduce banding
    //{0x520C, 0x1C, "0x0100",eReadWrite},
    
    //{0x520B, 0x41, "0x0100",eReadWrite}, //[0]ramp_sample_en_d [1]dacout_mode_en_d [2]rgain_float_en_d [3]rampout_byp_en_d [4]adc12b_en_d [5]cai_sample_en_d [6]bl_clamp_en_d [7]bl_float_en_d
    // Set this reg at main setting file to control 10/12bit mode switching.([4]adc12b_en_d)
    
    
    {0x520D, 0x40, "0x0100",eReadWrite}, //[2:0]ca_rst_sr_d [5:3]cds_sr_d [6]sf_sig_clamp_en_d [7]gcnt_buffer_byp_en_d 
    {0x5214, 0x18, "0x0100",eReadWrite}, //[0]bgp_pwr_save_en_d [1]bgp_pwr_save_mode_d [2]bgp_sample_byp_d [4:3]comp1_bias_sel_d<1:0> [6:5]comp2_bias_sel_d<1:0>
    {0x5215, 0x03, "0x0100",eReadWrite}, //(0119 saturation) //[1:0]rampbuf_bias_sel_d<1:0> [4:2]ramp_range_sel_d<2:0>
    {0x5216, 0x00, "0x0100",eReadWrite}, //[0]sf_biasn_sel_d [1]sf_bias_sel_d
    {0x521A, 0x10, "0x0100",eReadWrite}, //[0]otp_pump_en_1_d [4:1]vrpp_buffer_d<3:0> [6:5]vrpp_sel_d<1:0>
    {0x521B, 0x24, "0x0100",eReadWrite}, //[2:0]rxhi_sel_d<2:0> [5:3]sxhi_sel_d<2:0>
    {0x5232, 0x04, "0x0100",eReadWrite}, //(0119 saturation) //[2:0]Vrnp_clk_d 0:div2 , 1:div4, 2:div8, 3 div16, 4 div32, 5 div64
    {0x5233, 0x03, "0x0100",eReadWrite}, //(0119 RGB difference) //[2:0]Vrpp_clk_d 0:no div 1: div2, 2:div4, 3 div8, 4 div16, 5 div32, 6 div64
    
    //--ca-gain table
    
    {0x5106, 0xF0, "0x0100",eReadWrite}, //64x gain no refer to 32x gain
    {0x510E, 0xC1, "0x0100",eReadWrite}, //64x gain no refer to 32x gain
    {0x5166, 0xF0, "0x0100",eReadWrite}, //64x gain no refer to 32x gain
    {0x516E, 0xC1, "0x0100",eReadWrite}, //64x gain no refer to 32x gain
    {0x5196, 0xF0, "0x0100",eReadWrite}, //64x gain no refer to 32x gain
    {0x519E, 0xC1, "0x0100",eReadWrite}, //64x gain no refer to 32x gain
    
    
    {0x51C0, 0x80, "0x0100",eReadWrite}, //CAGAINTB_000_1 //(0122 CA-gain compensation)=>80
    {0x51C4, 0x80, "0x0100",eReadWrite}, //CAGAINTB_001_1 //(0122 CA-gain compensation)=>80
    {0x51C8, 0x80, "0x0100",eReadWrite}, //CAGAINTB_010_1 //(0122 CA-gain compensation)=>81
    {0x51CC, 0x80, "0x0100",eReadWrite}, //CAGAINTB_011_1 //(0122 CA-gain compensation)=>82
    {0x51D0, 0x80, "0x0100",eReadWrite}, //CAGAINTB_100_1 //(0122 CA-gain compensation)=>84
    {0x51D4, 0x80, "0x0100",eReadWrite}, //CAGAINTB_101_1 //(0122 CA-gain compensation)=>88  gain x16
    {0x51D8, 0x80, "0x0100",eReadWrite}, //CAGAINTB_110_1 //(0122 CA-gain compensation)=>88  gain x32
    {0x51DC, 0x80, "0x0100",eReadWrite}, //CAGAINTB_111_1   gain x64
    
    {0x51C1, 0x03, "0x0100",eReadWrite}, //CAGAINTB_000_2
    {0x51C5, 0x13, "0x0100",eReadWrite}, //CAGAINTB_001_2  x01
    {0x51C9, 0x17, "0x0100",eReadWrite}, //CAGAINTB_010_2  x02
    {0x51CD, 0x27, "0x0100",eReadWrite}, //CAGAINTB_011_2  x04  banding fixed
    {0x51D1, 0x27, "0x0100",eReadWrite}, //CAGAINTB_100_2  x08  banding fixed
    {0x51D5, 0x2B, "0x0100",eReadWrite}, //CAGAINTB_101_2  x16  banding fixed
    {0x51D9, 0x2B, "0x0100",eReadWrite}, //CAGAINTB_110_2  x32  banding fixed
    {0x51DD, 0x2B, "0x0100",eReadWrite}, //CAGAINTB_111_2  x64  banding fixed
    
    {0x51C2, 0x4B, "0x0100",eReadWrite}, //CAGAINTB_000_3
    {0x51C6, 0x4B, "0x0100",eReadWrite}, //CAGAINTB_001_3  x01
    {0x51CA, 0x4B, "0x0100",eReadWrite}, //CAGAINTB_010_3  x02
    {0x51CE, 0x49, "0x0100",eReadWrite}, //CAGAINTB_011_3  x04 banding fixed
    {0x51D2, 0x49, "0x0100",eReadWrite}, //CAGAINTB_100_3  x08 banding fixed
    {0x51D6, 0x49, "0x0100",eReadWrite}, //CAGAINTB_101_3  x16 banding fixed
    {0x51DA, 0x49, "0x0100",eReadWrite}, //CAGAINTB_110_3  x32 banding fixed
    {0x51DE, 0x49, "0x0100",eReadWrite}, //CAGAINTB_111_3  x64 banding fixed
    
    {0x51C3, 0x10, "0x0100",eReadWrite}, //CAGAINTB_000_4 //from shmoo result->78
    {0x51C7, 0x18, "0x0100",eReadWrite}, //(0119 dark-sun) //CAGAINTB_001_4 //from shmoo result->78
    {0x51CB, 0x10, "0x0100",eReadWrite}, //(0119 dark-sun) //CAGAINTB_010_4 By Andrew
    {0x51CF, 0x08, "0x0100",eReadWrite}, //(0119 dark-sun) //CAGAINTB_011_4 By Andrew
    {0x51D3, 0x08, "0x0100",eReadWrite}, //(0119 dark-sun) //CAGAINTB_100_4 By Andrew
    {0x51D7, 0x08, "0x0100",eReadWrite}, //CAGAINTB_101_4
    {0x51DB, 0x08, "0x0100",eReadWrite}, //CAGAINTB_110_4
    {0x51DF, 0x00, "0x0100",eReadWrite}, //CAGAINTB_111_4
    
    //--ca-gain table
    
    {0x51E0, 0x94, "0x0100",eReadWrite}, //
    {0x51E2, 0x94, "0x0100",eReadWrite}, //
    {0x51E4, 0x94, "0x0100",eReadWrite}, //
    {0x51E6, 0x94, "0x0100",eReadWrite}, //
    {0x51E1, 0x00, "0x0100",eReadWrite}, //
    {0x51E3, 0x00, "0x0100",eReadWrite}, //
    {0x51E5, 0x00, "0x0100",eReadWrite}, //
    {0x51E7, 0x00, "0x0100",eReadWrite}, //
    
    
    //End 20160119//
    
    //SSCG setting //20160226 by YL.
    {0x5264, 0x23, "0x0100",eReadWrite}, //SSCG lower HB 23,07,02~0.4438%
    {0x5265, 0x07, "0x0100",eReadWrite}, //SSCG lower LB
    {0x5266, 0x24, "0x0100",eReadWrite}, //SSCG upper HB(fixed value)
    {0x5267, 0x92, "0x0100",eReadWrite}, //SSCG upper LB(fixed value)
    {0x5268, 0x01, "0x0100",eReadWrite}, //[0]:SSCG disable,1=disable.
    //End of SSCG setting//20160226
    
    // Display dark row:
    // MIPI:     Set 0x5015[3]=1 + 0x4B6A=0x00
    // Parallel: Set 0x5015[3]=1
    
    
    //---------------------------------------------------
    // Static BPC
    //--------------------------------------------------
    {0xBAA2, 0xC0, "0x0100",eReadWrite}, //
    {0xBAA2, 0x40, "0x0100",eReadWrite}, //
    
    {0xBA90, 0x01, "0x0100",eReadWrite}, //define BPC_OTP_Enable
    {0xBA93, 0x02, "0x0100",eReadWrite}, //
    
    //--------------------------------------------------
    //Dynamic BPC Line Buffer Power Saving
    //---------------------------------------------------
    {0x3110, 0x0B, "0x0100",eReadWrite}, //[0]:static enable[1]:dynamic enable[2]DCC enable[3]DCC controlled by gain table
    {0x373E, 0x8A, "0x0100",eReadWrite}, //[7]: power saving with blanking 
    {0x373F, 0x8A, "0x0100",eReadWrite}, //[7]: power saving with blanking 
    
    {0x3701, 0x05, "0x0100",eReadWrite}, //Dynamic BPC CH1 HotPix TH
    {0x3709, 0x05, "0x0100",eReadWrite}, //Dynamic BPC CH2 HotPix TH
    {0x3703, 0x04, "0x0100",eReadWrite}, //Dynamic BPC CH1 Ratio
    {0x370B, 0x04, "0x0100",eReadWrite}, //Dynamic BPC CH2 Ratio
    //Dynamic BPC for sub_sampling
    {0x3713, 0x00, "0x0100",eReadWrite}, //Strength of CH1 Dynamic BPC
    {0x3717, 0x00, "0x0100",eReadWrite}, //Strength of CH2 Dynamic BPC
    
    
    //---------------------------------------------------
    // Temperature Sensor offset
    //---------------------------------------------------
    {0x5043, 0x01, "0x0100",eReadWrite}, //Temperature Sensor offset from [0] 0:OTP / 1:I2C
    
    {0x5040, 0x05, "0x0100",eReadWrite}, //[0] Temp disable
    {0x5044, 0x07, "0x0100",eReadWrite}, //Temp IIR enable[0], Weight=2h
    {0x6000, 0x0F, "0x0100",eReadWrite}, //[3:0] BLD upper bound
    {0x6001, 0xFF, "0x0100",eReadWrite}, //BLD upper bound Lb
    {0x6002, 0x1F, "0x0100",eReadWrite}, //[3:0] BLD low bound Hb [4] BLD low bound sign bit
    {0x6003, 0xFF, "0x0100",eReadWrite}, //BLD low bound Lb
    {0x6004, 0xC2, "0x0100",eReadWrite}, //[3:0] BLD INTG shift [4] BLD A part sel from Reg or OTP
                 	// [5] Read long & short sel [6] BLD Dmax_clip [7] BLD enable
    {0x6005, 0x00, "0x0100",eReadWrite}, //[1:0] BLD Cpix bb Hb [2] BLD Cpix bb sign bit [4] BLD Cpix bb sel
    {0x6006, 0x00, "0x0100",eReadWrite}, //[7:0] BLD Cpix bb Lb
    {0x6007, 0x00, "0x0100",eReadWrite}, //[1:0] BLD Cpix gb Hb [2] BLD Cpix gb sign bit [4] BLD Cpix gb sel
    {0x6008, 0x00, "0x0100",eReadWrite}, //[7:0] BLD Cpix gb Lb
    {0x6009, 0x00, "0x0100",eReadWrite}, //[1:0] BLD Cpix gr Hb [2] BLD Cpix gr sign bit [4] BLD Cpix gr sel
    {0x600A, 0x00, "0x0100",eReadWrite}, //[7:0] BLD Cpix gr Lb
    {0x600B, 0x00, "0x0100",eReadWrite}, //[1:0] BLD Cpix rr Hb [2] BLD Cpix rr sign bit [4] BLD Cpix rr sel
    {0x600C, 0x00, "0x0100",eReadWrite}, //[7:0] BLD Cpix rr Lb
    {0x600D, 0x20, "0x0100",eReadWrite}, //[6:0] BLD A part [7] BLD A part sign bit
    {0x600E, 0x00, "0x0100",eReadWrite}, //[0] BLD Tth Hb
    {0x600F, 0xA1, "0x0100",eReadWrite}, //[7:0] BLD Tth Lb
    {0x6010, 0x01, "0x0100",eReadWrite}, //[0] BLD Tstep ctrl
    {0x6011, 0x00, "0x0100",eReadWrite}, //[5:0] BLD Dt1 Hb [6] BLD Dt1 sign bit
    {0x6012, 0x06, "0x0100",eReadWrite}, //[7:0] BLD Dt1 Lb
    {0x6013, 0x00, "0x0100",eReadWrite}, //[5:0] BLD Dt2 Hb [6] BLD Dt2 sign bit
    {0x6014, 0x0B, "0x0100",eReadWrite}, //[7:0] BLD Dt2 Lb
    {0x6015, 0x00, "0x0100",eReadWrite}, //[5:0] BLD Dt3 Hb [6] BLD Dt3 sign bit
    {0x6016, 0x14, "0x0100",eReadWrite}, //[7:0] BLD Dt3 Lb
    {0x6017, 0x00, "0x0100",eReadWrite}, //[5:0] BLD Dt4 Hb [6] BLD Dt4 sign bit
    {0x6018, 0x25, "0x0100",eReadWrite}, //[7:0] BLD Dt4 Lb
    {0x6019, 0x00, "0x0100",eReadWrite}, //[5:0] BLD Dt5 Hb [6] BLD Dt5 sign bit
    {0x601A, 0x43, "0x0100",eReadWrite}, //[7:0] BLD Dt5 Lb
    {0x601B, 0x00, "0x0100",eReadWrite}, //[5:0] BLD Dmax Hb [6] BLD Dmax sign bit
    {0x601C, 0x82, "0x0100",eReadWrite}, //[7:0] BLD Dmax Lb
    
    //--------------------------------------------------
    // Turn on rolling shutter
    //---------------------------------------------------
    {0x0000, 0x00, "0x0100",eReadWrite}, //was 0000
    {0x0104, 0x01, "0x0100",eReadWrite}, //group hold
    {0x0104, 0x00, "0x0100",eReadWrite}, //group hold
    
    {0x0100, 0x03, "0x0100",eReadWrite}, //mode_select: 0h=stby, 2h=pwr_up, 1h/3h=streaming.
    {0x0000 ,0x00, "eTableEnd",eTableEnd}
    */
};

//HII gain
//zefa.chen@rock-chips.com
const sensor_again_table_t sensor_A_gain_table[]=
{
    {0x00, 10000 },
    {0x01, 10625 },
    {0x02, 11250 },
    {0x03, 11875 },
    {0x04, 12500 },
    {0x05, 13125 },
    {0x06, 13750 },
    {0x07, 14375 },
    {0x08, 15000 },
    {0x09, 15625 },
    {0x0A, 16250 },
    {0x0B, 16875 },
    {0x0C, 17500 },
    {0x0D, 18125 },
    {0x0E, 18750 },
    {0x0F, 19375 },
    {0x10, 20000 },
    {0x11, 21250 },
    {0x12, 22500 },
    {0x13, 23750 },
    {0x14, 25000 },
    {0x15, 26250 },
    {0x16, 27500 },
    {0x17, 28750 },
    {0x18, 30000 },
    {0x19, 31250 },
    {0x1A, 32500 },
    {0x1B, 33750 },
    {0x1C, 35000 },
    {0x1D, 36250 },
    {0x1E, 37500 },
    {0x1F, 38750 },
    {0x20, 40000 },
    {0x21, 42500 },
    {0x22, 45000 },
    {0x23, 47500 },
    {0x24, 50000 },
    {0x25, 52500 },
    {0x26, 55000 },
    {0x27, 57500 },
    {0x28, 60000 },
    {0x29, 62500 },
    {0x2A, 65000 },
    {0x2B, 67500 },
    {0x2C, 70000 },
    {0x2D, 72500 },
    {0x2E, 75000 },
    {0x2F, 77500 },
    {0x30, 80000 },
    {0x31, 85000 },
    {0x32, 90000 },
    {0x33, 95000 },
    {0x34, 100000},
    {0x35, 105000},
    {0x36, 110000},
    {0x37, 115000},
    {0x38, 120000},
    {0x39, 125000},
    {0x3A, 130000},
    {0x3B, 135000},
    {0x3C, 140000},
    {0x3D, 145000},
    {0x3E, 150000},
    {0x3F, 155000},
    {0x40, 160000},
    {0x41, 170000},
    {0x42, 180000},
    {0x43, 190000},
    {0x44, 200000},
    {0x45, 210000},
    {0x46, 220000},
    {0x47, 230000},
    {0x48, 240000},
    {0x49, 250000},
    {0x4A, 260000},
    {0x4B, 270000},
    {0x4C, 280000},
    {0x4D, 290000},
    {0x4E, 300000},
    {0x4F, 310000},
    {0x50, 320000},
    {0x51, 340000},
    {0x52, 360000},
    {0x53, 380000},
    {0x54, 400000},
    {0x55, 420000},
    {0x56, 440000},
    {0x57, 460000},
    {0x58, 480000},
    {0x59, 500000},
    {0x5A, 520000},
    {0x5B, 540000},
    {0x5C, 560000},
    {0x5D, 580000},
    {0x5E, 600000},
    {0x5F, 620000},
    {0xFF, 0}
    
};

/*
const IsiRegDescription_t Sensor_g_svga[] =
{

};
*/

const IsiRegDescription_t Sensor_g_1920x1080[] =
{
    {0x0340,0x0E, "eReadWrite",eReadWrite}, 

    {0x0341,0x82, "eReadWrite",eReadWrite},  //HiMOS_20160713

    {0x0342,0x05, "eReadWrite",eReadWrite}, 

    {0x0343,0x00, "eReadWrite",eReadWrite}, 

    {0x034C,0x07, "eReadWrite",eReadWrite}, 

    {0x034D,0x80, "eReadWrite",eReadWrite}, 

    {0x034E,0x04, "eReadWrite",eReadWrite}, 

    {0x034F,0x38, "eReadWrite",eReadWrite},                      	

    {0x0000, 0x00,"eReadWrite",eTableEnd}
};

const IsiRegDescription_t Sensor_g_1920x1080_30fps[] =
{
	{0x0340, 0x04,"eReadWrite",eTableEnd},

	{0x0341, 0xD6,"eReadWrite",eTableEnd},	//framelength=1106
     
	{0x0000, 0x00, "eReadWrite",eTableEnd}
	
};
const IsiRegDescription_t Sensor_g_1920x1080_20fps[] =
{
	{0x0340, 0x07,"eReadWrite",eTableEnd},

	{0x0341, 0x42,"eReadWrite",eTableEnd},	//framelength=1660
      
	{0x0000, 0x00, "eReadWrite",eTableEnd}
	
};
const IsiRegDescription_t Sensor_g_1920x1080_15fps[] =
{
	{0x0340, 0x09,"eReadWrite",eTableEnd},

	{0x0341, 0xAc,"eReadWrite",eTableEnd},	//framelength=2212
    
  {0x0000, 0x00, "eReadWrite",eTableEnd}
	
};

const IsiRegDescription_t Sensor_g_1920x1080_10fps[] =
{
	{0x0340, 0x0E,"eReadWrite",eTableEnd},

	{0x0341, 0x82,"eReadWrite",eTableEnd},	//framelength=3318
      
	{0x0000, 0x00, "eReadWrite",eTableEnd}
	
};


