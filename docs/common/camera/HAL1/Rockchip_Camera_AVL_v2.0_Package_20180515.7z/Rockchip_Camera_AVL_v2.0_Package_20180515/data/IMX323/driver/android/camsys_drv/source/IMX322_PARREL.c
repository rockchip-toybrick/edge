
/******************************************************************************
 *
 * Copyright 2010, Dream Chip Technologies GmbH. All rights reserved.
 * No part of this work may be reproduced, modified, distributed, transmitted,
 * transcribed, or translated into any language or computer format, in any form
 * or by any means without written permission of:
 * Dream Chip Technologies GmbH, Steinriede 10, 30827 Garbsen / Berenbostel,
 * Germany
 *
 *****************************************************************************/
/**
 * @file IMX322.c
 *
 * @brief
 *   ADD_DESCRIPTION_HERE
 *
 *****************************************************************************/
#include <ebase/types.h>
#include <ebase/trace.h>
#include <ebase/builtins.h>

#include <common/return_codes.h>
#include <common/misc.h>

#include <math.h>

#include "isi.h"
#include "isi_iss.h"
#include "isi_priv.h"

#include "IMX322_priv.h"

#define ALLON_DEBUG_ENABLE 0

#define CC_OFFSET_SCALING  2.0f
#define I2C_COMPLIANT_STARTBIT 1U
#define  IMX322_NEWEST_TUNING_XML "22-May-2014_OUYANG_IMX322_FX288_v1.0"

/******************************************************************************
 * local macro definitions
 *****************************************************************************/
CREATE_TRACER( IMX322_INFO , "IMX322: ", INFO,    1U );
CREATE_TRACER( IMX322_WARN , "IMX322: ", WARNING, 1U );
CREATE_TRACER( IMX322_ERROR, "IMX322: ", ERROR,   1U );

CREATE_TRACER( IMX322_DEBUG, "IMX322: ", INFO,     1U );

CREATE_TRACER( IMX322_REG_INFO , "IMX322: ", INFO, 1);
CREATE_TRACER( IMX322_REG_DEBUG, "IMX322: ", INFO, 0U );

#define IMX322_SLAVE_ADDR       0x34U
#define IMX322_SLAVE_ADDR2       0x34U
/**< i2c slave address of the IMX322 camera sensor */
#define IMX322_SLAVE_AF_ADDR    0x00U                           /**< i2c slave address of the IMX322 integrated AD5820 */

#define Sensor_MIN_GAIN_STEP   ( 0.04f ); /**< min gain step size used by GUI ( 32/(32-7) - 32/(32-6); min. reg value is 6 as of datasheet; depending on actual gain ) */
#define Sensor_MAX_GAIN_AEC    ( 11.22f )            /**< max. gain used by the AEC (arbitrarily chosen, recommended by Omnivision) */

/******************************************************************************
 * local variable declarations
 *****************************************************************************/
const char IMX322_g_acName[] = "IMX322_SOC_PARREL";
extern const IsiRegDescription_t IMX322_g_aRegDescription[];
extern const IsiRegDescription_t IMX322_1920x1080P30[];
extern const IsiRegDescription_t IMX322_1920x1080P15[];
extern const IsiRegDescription_t IMX322_streamon[];
extern const IsiRegDescription_t IMX322_streamoff[];


const IsiSensorCaps_t IMX322_g_IsiSensorDefaultConfig;


#define IMX322_I2C_START_BIT        (I2C_COMPLIANT_STARTBIT)    // I2C bus start condition
#define IMX322_I2C_NR_ADR_BYTES     (2U)                        // 1 byte base address and 2 bytes sub address
#define IMX322_I2C_NR_DAT_BYTES     (1U)                        // 8 bit registers


/******************************************************************************
 * local function prototypes
 *****************************************************************************/
static RESULT IMX322_IsiCreateSensorIss( IsiSensorInstanceConfig_t *pConfig );
static RESULT IMX322_IsiReleaseSensorIss( IsiSensorHandle_t handle );
static RESULT IMX322_IsiGetCapsIss( IsiSensorHandle_t handle, IsiSensorCaps_t *pIsiSensorCaps );
static RESULT IMX322_IsiSetupSensorIss( IsiSensorHandle_t handle, const IsiSensorConfig_t *pConfig );
static RESULT IMX322_IsiSensorSetStreamingIss( IsiSensorHandle_t handle, bool_t on );
static RESULT IMX322_IsiSensorSetPowerIss( IsiSensorHandle_t handle, bool_t on );
static RESULT IMX322_IsiCheckSensorConnectionIss( IsiSensorHandle_t handle );
static RESULT IMX322_IsiGetSensorRevisionIss( IsiSensorHandle_t handle, uint32_t *p_value);

static RESULT IMX322_IsiGetGainLimitsIss( IsiSensorHandle_t handle, float *pMinGain, float *pMaxGain);
static RESULT IMX322_IsiGetIntegrationTimeLimitsIss( IsiSensorHandle_t handle, float *pMinIntegrationTime, float *pMaxIntegrationTime );
static RESULT IMX322_IsiExposureControlIss( IsiSensorHandle_t handle, float NewGain, float NewIntegrationTime, uint8_t *pNumberOfFramesToSkip, float *pSetGain, float *pSetIntegrationTime );
static RESULT IMX322_IsiGetCurrentExposureIss( IsiSensorHandle_t handle, float *pSetGain, float *pSetIntegrationTime );
static RESULT IMX322_IsiGetAfpsInfoIss ( IsiSensorHandle_t handle, uint32_t Resolution, IsiAfpsInfo_t* pAfpsInfo);
static RESULT IMX322_IsiGetGainIss( IsiSensorHandle_t handle, float *pSetGain );
static RESULT IMX322_IsiGetGainIncrementIss( IsiSensorHandle_t handle, float *pIncr );
static RESULT IMX322_IsiSetGainIss( IsiSensorHandle_t handle, float NewGain, float *pSetGain );
static RESULT IMX322_IsiGetIntegrationTimeIss( IsiSensorHandle_t handle, float *pSetIntegrationTime );
static RESULT IMX322_IsiGetIntegrationTimeIncrementIss( IsiSensorHandle_t handle, float *pIncr );
static RESULT IMX322_IsiSetIntegrationTimeIss( IsiSensorHandle_t handle, float NewIntegrationTime, float *pSetIntegrationTime, uint8_t *pNumberOfFramesToSkip );
static RESULT IMX322_IsiGetResolutionIss( IsiSensorHandle_t handle, uint32_t *pSetResolution );


static RESULT IMX322_IsiRegReadIss( IsiSensorHandle_t handle, const uint32_t address, uint32_t *p_value );
static RESULT IMX322_IsiRegWriteIss( IsiSensorHandle_t handle, const uint32_t address, const uint32_t value );

static RESULT IMX322_IsiGetCalibKFactor( IsiSensorHandle_t handle, Isi1x1FloatMatrix_t **pIsiKFactor );
static RESULT IMX322_IsiGetCalibPcaMatrix( IsiSensorHandle_t   handle, Isi3x2FloatMatrix_t **pIsiPcaMatrix );
static RESULT IMX322_IsiGetCalibSvdMeanValue( IsiSensorHandle_t   handle, Isi3x1FloatMatrix_t **pIsiSvdMeanValue );
static RESULT IMX322_IsiGetCalibCenterLine( IsiSensorHandle_t   handle, IsiLine_t  **ptIsiCenterLine);
static RESULT IMX322_IsiGetCalibClipParam( IsiSensorHandle_t   handle, IsiAwbClipParm_t    **pIsiClipParam );
static RESULT IMX322_IsiGetCalibGlobalFadeParam( IsiSensorHandle_t       handle, IsiAwbGlobalFadeParm_t  **ptIsiGlobalFadeParam);
static RESULT IMX322_IsiGetCalibFadeParam( IsiSensorHandle_t   handle, IsiAwbFade2Parm_t   **ptIsiFadeParam);
static RESULT IMX322_IsiGetIlluProfile( IsiSensorHandle_t   handle, const uint32_t CieProfile, IsiIlluProfile_t **ptIsiIlluProfile );

static RESULT IMX322_IsiMdiInitMotoDriveMds( IsiSensorHandle_t handle );
static RESULT IMX322_IsiMdiSetupMotoDrive( IsiSensorHandle_t handle, uint32_t *pMaxStep );
static RESULT IMX322_IsiMdiFocusSet( IsiSensorHandle_t handle, const uint32_t Position );
static RESULT IMX322_IsiMdiFocusGet( IsiSensorHandle_t handle, uint32_t *pAbsStep );
static RESULT IMX322_IsiMdiFocusCalibrate( IsiSensorHandle_t handle );

static RESULT IMX322_IsiGetSensorMipiInfoIss( IsiSensorHandle_t handle, IsiSensorMipiInfo *ptIsiSensorMipiInfo);
static RESULT IMX322_IsiGetSensorIsiVersion(  IsiSensorHandle_t   handle, unsigned int* pVersion);



/*****************************************************************************/
/**
 *          IMX322_IsiCreateSensorIss
 *
 * @brief   This function creates a new IMX322 sensor instance handle.
 *
 * @param   pConfig     configuration structure to create the instance
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 * @retval  RET_OUTOFMEM
 *
 *****************************************************************************/
static RESULT IMX322_IsiCreateSensorIss
(
    IsiSensorInstanceConfig_t *pConfig
)
{
    RESULT result = RET_SUCCESS;

    IMX322_Context_t *pIMX322Ctx;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( (pConfig == NULL) || (pConfig->pSensor ==NULL) )
    {
        return ( RET_NULL_POINTER );
    }

    pIMX322Ctx = ( IMX322_Context_t * )malloc ( sizeof (IMX322_Context_t) );
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR,  "%s: Can't allocate ov14825 context\n",  __FUNCTION__ );
        return ( RET_OUTOFMEM );
    }
    MEMSET( pIMX322Ctx, 0, sizeof( IMX322_Context_t ) );

    result = HalAddRef( pConfig->HalHandle );
    if ( result != RET_SUCCESS )
    {
        free ( pIMX322Ctx );
        return ( result );
    }

    pIMX322Ctx->IsiCtx.HalHandle              = pConfig->HalHandle;
    pIMX322Ctx->IsiCtx.HalDevID               = pConfig->HalDevID;
    pIMX322Ctx->IsiCtx.I2cBusNum              = pConfig->I2cBusNum;
    pIMX322Ctx->IsiCtx.SlaveAddress           = ( pConfig->SlaveAddr == 0 ) ? IMX322_SLAVE_ADDR : pConfig->SlaveAddr;
    pIMX322Ctx->IsiCtx.NrOfAddressBytes       = IMX322_I2C_NR_ADR_BYTES;

    pIMX322Ctx->IsiCtx.I2cAfBusNum            = pConfig->I2cAfBusNum;
    pIMX322Ctx->IsiCtx.SlaveAfAddress         = ( pConfig->SlaveAfAddr == 0 ) ? IMX322_SLAVE_AF_ADDR : pConfig->SlaveAfAddr;
    pIMX322Ctx->IsiCtx.NrOfAfAddressBytes     = 0;

    pIMX322Ctx->IsiCtx.pSensor                = pConfig->pSensor;

    pIMX322Ctx->Configured             = BOOL_FALSE;
    pIMX322Ctx->Streaming              = BOOL_FALSE;
    pIMX322Ctx->TestPattern            = BOOL_FALSE;
    pIMX322Ctx->isAfpsRun              = BOOL_FALSE;

    pConfig->hSensor = ( IsiSensorHandle_t )pIMX322Ctx;

    result = HalSetCamConfig( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, true, true, false );
    RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

    result = HalSetClock( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, 10000000U);
    RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiReleaseSensorIss
 *
 * @brief   This function destroys/releases an IMX322 sensor instance.
 *
 * @param   handle      IMX322 sensor instance handle
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 *
 *****************************************************************************/
static RESULT IMX322_IsiReleaseSensorIss
(
    IsiSensorHandle_t handle
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    (void)IMX322_IsiSensorSetStreamingIss( pIMX322Ctx, BOOL_FALSE );
    (void)IMX322_IsiSensorSetPowerIss( pIMX322Ctx, BOOL_FALSE );

    (void)HalDelRef( pIMX322Ctx->IsiCtx.HalHandle );

    MEMSET( pIMX322Ctx, 0, sizeof( IMX322_Context_t ) );
    free ( pIMX322Ctx );

    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCapsIss
 *
 * @brief   fills in the correct pointers for the sensor description struct
 *
 * @param   param1      pointer to sensor capabilities structure
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCapsIssInternal
(
    IsiSensorCaps_t   *pIsiSensorCaps
)
{
    RESULT result = RET_SUCCESS;
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    
    if ( pIsiSensorCaps == NULL )
    {
        return ( RET_NULL_POINTER );
    }
    else
    {
        switch (pIsiSensorCaps->Index) 
        {
        
            case 0:
            {
                pIsiSensorCaps->Resolution = ISI_RES_TV1080P30;
                break;
            }
            /*
            case 0:
            {
                pIsiSensorCaps->Resolution = ISI_RES_TV1080P15;
                break;
            } 
            */
            default:
            {
                result = RET_OUTOFRANGE;
                goto end;
            }

        }
    
#ifdef BT656_10BIT
        pIsiSensorCaps->BusWidth        = ISI_BUSWIDTH_10BIT;
        pIsiSensorCaps->Mode            = ISI_MODE_BAY_BT656;//ISI_MODE_BAY_BT656;//ISI_MODE_BAYER;
#else
        pIsiSensorCaps->BusWidth        = ISI_BUSWIDTH_12BIT;
        pIsiSensorCaps->Mode            = ISI_MODE_BAY_BT656;//ISI_MODE_BAY_BT656;//ISI_MODE_BAYER;
#endif
        pIsiSensorCaps->FieldSelection  = ISI_FIELDSEL_BOTH;
        pIsiSensorCaps->YCSequence      = ISI_YCSEQ_YCBYCR;           
        pIsiSensorCaps->Conv422         = ISI_CONV422_COSITED;
        pIsiSensorCaps->BPat            = ISI_BPAT_GBGBRGRG;
        pIsiSensorCaps->HPol            = ISI_HPOL_REFPOS;
        pIsiSensorCaps->VPol            = ISI_VPOL_POS;
        pIsiSensorCaps->Edge            = ISI_EDGE_RISING;
        pIsiSensorCaps->Bls             = ISI_BLS_OFF;
        pIsiSensorCaps->Gamma           = ISI_GAMMA_OFF;
        pIsiSensorCaps->CConv           = ISI_CCONV_ON;
        pIsiSensorCaps->BLC             = ( ISI_BLC_AUTO );
        pIsiSensorCaps->AGC             = ( ISI_AGC_AUTO );
        pIsiSensorCaps->AWB             = ( ISI_AWB_AUTO );
        pIsiSensorCaps->AEC             = ( ISI_AEC_AUTO );
        pIsiSensorCaps->DPCC            = ( ISI_DPCC_AUTO );

        pIsiSensorCaps->DwnSz           = ISI_DWNSZ_SUBSMPL;
        pIsiSensorCaps->CieProfile      = 0;
        pIsiSensorCaps->SmiaMode        = ISI_SMIA_OFF;
        pIsiSensorCaps->MipiMode        = ISI_MIPI_OFF;
        pIsiSensorCaps->AfpsResolutions = ( ISI_AFPS_NOTSUPP );
	pIsiSensorCaps->SensorOutputMode = ISI_SENSOR_OUTPUT_MODE_RAW;
    }
end:  

    return ( result );
}
static RESULT IMX322_IsiGetCapsIss
(
    IsiSensorHandle_t handle,
    IsiSensorCaps_t   *pIsiSensorCaps
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    result = IMX322_IsiGetCapsIssInternal(pIsiSensorCaps);
    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_g_IsiSensorDefaultConfig
 *
 * @brief   recommended default configuration for application use via call
 *          to IsiGetSensorIss()
 *
 *****************************************************************************/
const IsiSensorCaps_t IMX322_g_IsiSensorDefaultConfig =
{
#ifdef BT656_10BIT
    ISI_BUSWIDTH_10BIT,         // BusWidth
    ISI_MODE_BAY_BT656,				//ISI_MODE_BAY_BT656,//ISI_MODE_BAYER,			// Bayer data with separate h/v sync lines
#else
    ISI_BUSWIDTH_12BIT,         // BusWidth
    ISI_MODE_BAY_BT656,				//ISI_MODE_BAY_BT656,//ISI_MODE_BAYER,			// Bayer data with separate h/v sync lines
#endif
    ISI_FIELDSEL_BOTH,          // FieldSel
    ISI_YCSEQ_YCBYCR,           // YCSeq
    ISI_CONV422_COSITED,      // Conv422
    ISI_BPAT_GBGBRGRG,          // BPat
    ISI_HPOL_REFPOS,            // HPol
    ISI_VPOL_POS,               // VPol
    ISI_EDGE_RISING,            // Edge
    ISI_BLS_OFF,                // Bls
    ISI_GAMMA_OFF,              // Gamma
    ISI_CCONV_ON,              // CConv
    ISI_RES_TV1080P30,          // Res
    ISI_DWNSZ_SUBSMPL,          // DwnSz
    ISI_BLC_AUTO,               // BLC
    ISI_AGC_AUTO,                // AGC
    ISI_AWB_AUTO,                // AWB
    ISI_AEC_AUTO,                // AEC
    ISI_DPCC_AUTO,               // DPCC
    0,            // CieProfile, this is also used as start profile for AWB (if not altered by menu settings)
    ISI_SMIA_OFF,               // SmiaMode
    ISI_MIPI_OFF,       // MipiMode
    ISI_AFPS_NOTSUPP,           // AfpsResolutions
    ISI_SENSOR_OUTPUT_MODE_RAW,
    0,
};



/*****************************************************************************/
/**
 *          IMX322_SetupOutputFormat
 *
 * @brief   Setup of the image sensor considering the given configuration.
 *
 * @param   handle      IMX322 sensor instance handle
 * @param   pConfig     pointer to sensor configuration structure
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_SetupOutputFormat
(
    IMX322_Context_t       *pIMX322Ctx,
    const IsiSensorConfig_t *pConfig
)
{
    RESULT result = RET_SUCCESS;
    return result;

    TRACE( IMX322_INFO, "%s%s (enter)\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    /* bus-width */
    switch ( pConfig->BusWidth )        /* only ISI_BUSWIDTH_12BIT supported, no configuration needed here */
    {
        case ISI_BUSWIDTH_10BIT:
        case ISI_BUSWIDTH_8BIT_ZZ:
        case ISI_BUSWIDTH_12BIT:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: bus width not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    /* mode */
    switch ( pConfig->Mode )            /* only ISI_MODE_BAYER supported, no configuration needed here */
    {
        case( ISI_MODE_MIPI ):
        case ISI_MODE_BAYER:
        case ISI_MODE_BT601:
        case ISI_MODE_PICT:
        case  ISI_MODE_DATA:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: mode not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    /* field-selection */
    switch ( pConfig->FieldSelection )  /* only ISI_FIELDSEL_BOTH supported, no configuration needed */
    {
        case ISI_FIELDSEL_BOTH:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: field selection not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    switch ( pConfig->YCSequence )
    {
        default:
        {
            break;
        }
    }

    /* 422 conversion */
    switch ( pConfig->Conv422 )         /* only ISI_CONV422_NOCOSITED supported, no configuration needed */
    {
        case ISI_CONV422_NOCOSITED:
        case ISI_CONV422_COSITED:
        case ISI_CONV422_INTER:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: 422 conversion not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    /* bayer-pattern */
    switch ( pConfig->BPat )            /* only ISI_BPAT_BGBGGRGR supported, no configuration needed */
    {
        case ISI_BPAT_GBGBRGRG:
        case ISI_BPAT_RGRGGBGB:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: bayer pattern not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    /* horizontal polarity */
    switch ( pConfig->HPol )            /* only ISI_HPOL_REFPOS supported, no configuration needed */
    {
        case ISI_HPOL_REFPOS:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: HPol not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    /* vertical polarity */
    switch ( pConfig->VPol )            /* only ISI_VPOL_POS supported, no configuration needed */
    {
        case ISI_VPOL_POS:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: VPol not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }


    /* edge */
    switch ( pConfig->Edge )            /* only ISI_EDGE_RISING supported, no configuration needed */
    {
        case ISI_EDGE_RISING:
        {
            break;
        }

        case ISI_EDGE_FALLING:          /*TODO for MIPI debug*/
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s:  edge mode not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    /* gamma */
    switch ( pConfig->Gamma )           /* only ISI_GAMMA_OFF supported, no configuration needed */
    {
        case ISI_GAMMA_ON:
        case ISI_GAMMA_OFF:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s:  gamma not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    /* color conversion */
    switch ( pConfig->CConv )           /* only ISI_CCONV_OFF supported, no configuration needed */
    {
        case ISI_CCONV_OFF:
        case ISI_CCONV_ON:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: color conversion not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    switch ( pConfig->SmiaMode )        /* only ISI_SMIA_OFF supported, no configuration needed */
    {
        case ISI_SMIA_OFF:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: SMIA mode not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    switch ( pConfig->MipiMode )        /* only ISI_MIPI_MODE_RAW_12 supported, no configuration needed */
    {
        case ISI_MIPI_MODE_RAW_10:
        case ISI_MIPI_OFF:
        {
            break;
        }

        default:
        {
            TRACE( IMX322_ERROR, "%s%s: MIPI mode not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            return ( RET_NOTSUPP );
        }
    }

    switch ( pConfig->AfpsResolutions ) /* no configuration needed */
    {
        case ISI_AFPS_NOTSUPP:
        {
            break;
        }
        default:
        {
            // don't care about what comes in here
            //TRACE( IMX322_ERROR, "%s%s: AFPS not supported\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"" );
            //return ( RET_NOTSUPP );
        }
    }

    TRACE( IMX322_INFO, "%s%s (exit)\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"");

    return ( result );
}

int IMX322_get_PCLK( IMX322_Context_t *pIMX322Ctx, int XVCLK)
{
    // calculate PCLK
    #if ALLON_DEBUG_ENABLE
    TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    return 0;
}

/*****************************************************************************/
/**
 *          IMX322_SetupOutputWindow
 *
 * @brief   Setup of the image sensor considering the given configuration.
 *
 * @param   handle      IMX322 sensor instance handle
 * @param   pConfig     pointer to sensor configuration structure
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_SetupOutputWindow
(
    IMX322_Context_t        *pIMX322Ctx,
    const IsiSensorConfig_t *pConfig
)
{
    RESULT result     = RET_SUCCESS;
	float    rVtPixClkFreq      = 0.0f;	
    uint16_t usFrameLengthLines = 0;
    uint16_t usLineLengthPck    = 0;
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
        /* resolution */
    switch ( pConfig->Resolution )
    {
        case ISI_RES_TV1080P30:
        {
        	osSleep( 100 );
			TRACE( IMX322_ERROR, "Allon SetupOutputWindow%s -----------start-----------------\n", __FUNCTION__);
            if((result = IsiRegDefaultsApply((IsiSensorHandle_t)pIMX322Ctx,IMX322_1920x1080P30)) != RET_SUCCESS){
                TRACE( IMX322_ERROR, "%s: failed to set  ISI_RES_TV1080P30 \n", __FUNCTION__ );
				TRACE( IMX322_ERROR, "%s -----------start-----------------\n", __FUNCTION__);
				IsiSensorHandle_t handle = (IsiSensorHandle_t)pIMX322Ctx;
				uint32_t val = 0;
			   IMX322_IsiRegReadIss(handle, 0x0100, &val);
			   TRACE( IMX322_ERROR, "%s 0x0100:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0112, &val);
			   TRACE( IMX322_ERROR, "%s 0x0100:0x%x\n", __FUNCTION__,val);				   
			   IMX322_IsiRegReadIss(handle, 0x0009, &val);
			   TRACE( IMX322_ERROR, "%s 0x0009:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0340, &val);
			   TRACE( IMX322_ERROR, "%s 0x0340:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0341, &val);
			   TRACE( IMX322_ERROR, "%s 0x0341:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0342, &val);
			   TRACE( IMX322_ERROR, "%s 0x0342:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0343, &val);
			   TRACE( IMX322_ERROR, "%s 0x0343:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3000, &val);
			   TRACE( IMX322_ERROR, "%s 0x3000:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3002, &val);
			   TRACE( IMX322_ERROR, "%s 0x3002:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3011, &val);
			   TRACE( IMX322_ERROR, "%s 0x3011:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3013, &val);
			   TRACE( IMX322_ERROR, "%s 0x3013:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3016, &val);
			   TRACE( IMX322_ERROR, "%s 0x3016:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x301a, &val);
			   TRACE( IMX322_ERROR, "%s 0x301a:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x301f, &val);
			   TRACE( IMX322_ERROR, "%s 0x301f:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3021, &val);
			   TRACE( IMX322_ERROR, "%s 0x3021:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3022, &val);
			   TRACE( IMX322_ERROR, "%s 0x3022:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3027, &val);
			   TRACE( IMX322_ERROR, "%s 0x3027:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x302c, &val);
			   TRACE( IMX322_ERROR, "%s 0x302c:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x304f, &val);
			   TRACE( IMX322_ERROR, "%s 0x304f:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3054, &val);
			   TRACE( IMX322_ERROR, "%s 0x3054:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x307a, &val);
			   TRACE( IMX322_ERROR, "%s 0x307a:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x307b, &val);
			   TRACE( IMX322_ERROR, "%s 0x307b:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3117, &val);
			   TRACE( IMX322_ERROR, "%s 0x3117:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x302d, &val);
			   TRACE( IMX322_ERROR, "%s 0x302d:0x%x\n", __FUNCTION__,val);
			   TRACE( IMX322_ERROR, "%s -----------end-----------------\n", __FUNCTION__); 
            }else{

                TRACE( IMX322_ERROR, "%s: success to set  ISI_RES_TV1080P30 \n", __FUNCTION__ );
				IsiSensorHandle_t handle = (IsiSensorHandle_t)pIMX322Ctx;
				uint32_t val = 0;
			   IMX322_IsiRegReadIss(handle, 0x0104, &val);
			   TRACE( IMX322_ERROR, "%s 0x0104:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0100, &val);
			   TRACE( IMX322_ERROR, "%s 0x0100:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0009, &val);
			   TRACE( IMX322_ERROR, "%s 0x0009:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0340, &val);
			   TRACE( IMX322_ERROR, "%s 0x0340:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0341, &val);
			   TRACE( IMX322_ERROR, "%s 0x0341:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0342, &val);
			   TRACE( IMX322_ERROR, "%s 0x0342:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0343, &val);
			   TRACE( IMX322_ERROR, "%s 0x0343:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3000, &val);
			   TRACE( IMX322_ERROR, "%s 0x3000:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3002, &val);
			   TRACE( IMX322_ERROR, "%s 0x3002:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3011, &val);
			   TRACE( IMX322_ERROR, "%s 0x3011:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3013, &val);
			   TRACE( IMX322_ERROR, "%s 0x3013:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3016, &val);
			   TRACE( IMX322_ERROR, "%s 0x3016:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x301a, &val);
			   TRACE( IMX322_ERROR, "%s 0x301a:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x301f, &val);
			   TRACE( IMX322_ERROR, "%s 0x301f:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3021, &val);
			   TRACE( IMX322_ERROR, "%s 0x3021:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3022, &val);
			   TRACE( IMX322_ERROR, "%s 0x3022:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3027, &val);
			   TRACE( IMX322_ERROR, "%s 0x3027:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x302c, &val);
			   TRACE( IMX322_ERROR, "%s 0x302c:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x304f, &val);
			   TRACE( IMX322_ERROR, "%s 0x304f:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3054, &val);
			   TRACE( IMX322_ERROR, "%s 0x3054:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x307a, &val);
			   TRACE( IMX322_ERROR, "%s 0x307a:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x307b, &val);
			   TRACE( IMX322_ERROR, "%s 0x307b:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3117, &val);
			   TRACE( IMX322_ERROR, "%s 0x3117:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x302d, &val);
			   TRACE( IMX322_ERROR, "%s 0x302d:0x%x\n", __FUNCTION__,val);
			   TRACE( IMX322_ERROR, "%s -----------end-----------------\n", __FUNCTION__); 
            }
            break;
        }
        /*
        case ISI_RES_TV1080P15:
        {
            if((result = IsiRegDefaultsApply((IsiSensorHandle_t)pIMX322Ctx,IMX322_1920x1080P15)) != RET_SUCCESS){
                TRACE( IMX322_ERROR, "%s: failed to set  ISI_RES_TV1080P15 \n", __FUNCTION__ );
            }else{

                TRACE( IMX322_ERROR, "%s: success to set  ISI_RES_TV1080P15 \n", __FUNCTION__ );
            }
            break;
        }
*/
        default:
        {
            TRACE( IMX322_ERROR, "%s: Resolution not supported\n", __FUNCTION__ );
            return ( RET_NOTSUPP );
        }
    }

	// store frame timing for later use in AEC module
	rVtPixClkFreq = 74250000;  
	usLineLengthPck = 0x044c;
	usFrameLengthLines = 0x0465;
    pIMX322Ctx->VtPixClkFreq     = rVtPixClkFreq;
    pIMX322Ctx->LineLengthPck    = usLineLengthPck;
    pIMX322Ctx->FrameLengthLines = usFrameLengthLines;	
	pIMX322Ctx->AecMaxIntegrationTime = (((float)pIMX322Ctx->FrameLengthLines - 0.3) * (float)pIMX322Ctx->LineLengthPck) / pIMX322Ctx->VtPixClkFreq;
    return ( result );
}




/*****************************************************************************/
/**
 *          IMX322_SetupImageControl
 *
 * @brief   Sets the image control functions (BLC, AGC, AWB, AEC, DPCC ...)
 *
 * @param   handle      IMX322 sensor instance handle
 * @param   pConfig     pointer to sensor configuration structure
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_SetupImageControl
(
    IMX322_Context_t        *pIMX322Ctx,
    const IsiSensorConfig_t *pConfig
)
{
    RESULT result = RET_SUCCESS;

    uint32_t RegValue = 0U;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif


    return ( result );
}


/*****************************************************************************/
/**
 *          IMX322_AecSetModeParameters
 *
 * @brief   This function fills in the correct parameters in IMX322-Instances
 *          according to AEC mode selection in IsiSensorConfig_t.
 *
 * @note    It is assumed that IsiSetupOutputWindow has been called before
 *          to fill in correct values in instance structure.
 *
 * @param   handle      IMX322 context
 * @param   pConfig     pointer to sensor configuration structure
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_AecSetModeParameters
(
    IMX322_Context_t       *pIMX322Ctx,
    const IsiSensorConfig_t *pConfig
)
{
	RESULT result = RET_SUCCESS;

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
	 //TRACE( Sensor_INFO, "%s%s (enter)\n", __FUNCTION__, pSensorCtx->isAfpsRun?"(AFPS)":"");
	 TRACE( IMX322_INFO, "%s%s (enter)	Res: 0x%x  0x%x\n", __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"",
		 pIMX322Ctx->Config.Resolution, pConfig->Resolution);
	
	 if ( (pIMX322Ctx->VtPixClkFreq == 0.0f) )
	 {
		 TRACE( IMX322_INFO, "%s%s: Division by zero!\n", __FUNCTION__  );
		 return ( RET_OUTOFRANGE );
	 }
	
	 /* Integration time = (1 frame period) - (INTEG_TIME)*(1H period) - 0.3[H] */
	 /* INTEG_TIME: 0 ~ (number of lines per frame -1) */
	 pIMX322Ctx->AecMaxIntegrationTime = (((float)pIMX322Ctx->FrameLengthLines - 0.3) * (float)pIMX322Ctx->LineLengthPck) / pIMX322Ctx->VtPixClkFreq;
	 pIMX322Ctx->AecMinIntegrationTime = (0.7 * (float)pIMX322Ctx->LineLengthPck) / pIMX322Ctx->VtPixClkFreq;	 
	
	 pIMX322Ctx->AecMaxGain = Sensor_MAX_GAIN_AEC;
	 pIMX322Ctx->AecMinGain = 1.0f;
	
	 pIMX322Ctx->AecIntegrationTimeIncrement = ((float)pIMX322Ctx->LineLengthPck) / pIMX322Ctx->VtPixClkFreq;
	 pIMX322Ctx->AecGainIncrement = Sensor_MIN_GAIN_STEP;
	
	 //reflects the state of the sensor registers, must equal default settings
	 pIMX322Ctx->AecCurGain 			  = pIMX322Ctx->AecMinGain;
	 pIMX322Ctx->AecCurIntegrationTime	  = 0.0f;
	 pIMX322Ctx->OldCoarseIntegrationTime = 0;
	 pIMX322Ctx->OldFineIntegrationTime   = 0;
	 //pSensorCtx->GroupHold				= true; //must be true (for unknown reason) to correctly set gain the first time
	
	 TRACE( IMX322_ERROR, "%s%s (exit)\n AecMaxIntegrationTime:%f\n AecMinIntegrationTime:%f\n FrameLengthLines:%d\n LineLengthPck:%d\n VtPixClkFreq:%f\n",
	 __FUNCTION__, pIMX322Ctx->isAfpsRun?"(AFPS)":"",
	 pIMX322Ctx->AecMaxIntegrationTime,
	 pIMX322Ctx->AecMinIntegrationTime,
	 pIMX322Ctx->FrameLengthLines,
	 pIMX322Ctx->LineLengthPck,
	 pIMX322Ctx->VtPixClkFreq
	 );
	
	 return ( result );

}


/*****************************************************************************/
/**
 *          IMX322_IsiSetupSensorIss
 *
 * @brief   Setup of the image sensor considering the given configuration.
 *
 * @param   handle      IMX322 sensor instance handle
 * @param   pConfig     pointer to sensor configuration structure
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiSetupSensorIss
(
    IsiSensorHandle_t       handle,
    const IsiSensorConfig_t *pConfig
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    uint32_t RegValue = 0;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);
	
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
	
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pConfig == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid configuration (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_NULL_POINTER );
    }

    if ( pIMX322Ctx->Streaming != BOOL_FALSE )
    {
        return RET_WRONG_STATE;
    }

    MEMCPY( &pIMX322Ctx->Config, pConfig, sizeof( IsiSensorConfig_t ) );

    /* 2.) write default values derived from datasheet and evaluation kit (static setup altered by dynamic setup further below) */
    result = IsiRegDefaultsApply( pIMX322Ctx, IMX322_g_aRegDescription );
    if ( result != RET_SUCCESS )
    {
        return ( result );
    }

    /* sleep a while, that sensor can take over new default values */
    osSleep( 10 );
    #if 0


    /* 3.) verify default values to make sure everything has been written correctly as expected */
    result = IsiRegDefaultsVerify( pIMX322Ctx, IMX322_g_aRegDescription );
    if ( result != RET_SUCCESS )
    {
        return ( result );
    }
    // output of pclk for measurement (only debugging)
    result = IMX322_IsiRegWriteIss( pIMX322Ctx, 0x3009U, 0x10U );
    RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );
    #endif

    /* 4.) setup output format (RAW10|RAW12) */
    result = IMX322_SetupOutputFormat( pIMX322Ctx, pConfig );
    if ( result != RET_SUCCESS )
    {
        TRACE( IMX322_ERROR, "%s: SetupOutputFormat failed.\n", __FUNCTION__);
        return ( result );
    }

    /* 5.) setup output window */
    result = IMX322_SetupOutputWindow( pIMX322Ctx, pConfig );
    if ( result != RET_SUCCESS )
    {
        TRACE( IMX322_ERROR, "%s: SetupOutputWindow failed.\n", __FUNCTION__);
        return ( result );
    }

    result = IMX322_SetupImageControl( pIMX322Ctx, pConfig );
    if ( result != RET_SUCCESS )
    {
        TRACE( IMX322_ERROR, "%s: SetupImageControl failed.\n", __FUNCTION__);
        return ( result );
    }

    result = IMX322_AecSetModeParameters( pIMX322Ctx, pConfig );
    if ( result != RET_SUCCESS )
    {
        TRACE( IMX322_ERROR, "%s: AecSetModeParameters failed.\n", __FUNCTION__);
        return ( result );
    }
    if (result == RET_SUCCESS)
    {
        pIMX322Ctx->Configured = BOOL_TRUE;
    }

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiChangeSensorResolutionIss
 *
 * @brief   Change image sensor resolution while keeping all other static settings.
 *          Dynamic settings like current gain & integration time are kept as
 *          close as possible. Sensor needs 2 frames to engage (first 2 frames
 *          are not correctly exposed!).
 *
 * @note    Re-read current & min/max values as they will probably have changed!
 *
 * @param   handle                  Sensor instance handle
 * @param   Resolution              new resolution ID
 * @param   pNumberOfFramesToSkip   reference to storage for number of frames to skip
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_WRONG_STATE
 * @retval  RET_OUTOFRANGE
 *
 *****************************************************************************/
static RESULT IMX322_IsiChangeSensorResolutionIss
(
    IsiSensorHandle_t   handle,
    uint32_t            Resolution,
    uint8_t             *pNumberOfFramesToSkip
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if (pNumberOfFramesToSkip == NULL)
    {
        return ( RET_NULL_POINTER );
    }

    if ( (pIMX322Ctx->Configured != BOOL_TRUE) || (pIMX322Ctx->Streaming != BOOL_FALSE) )
    {
        return RET_WRONG_STATE;
    }

    IsiSensorCaps_t Caps;    
    Caps.Index = 0;
    Caps.Resolution = 0;
    while (IMX322_IsiGetCapsIss( handle, &Caps) == RET_SUCCESS) {
        if (Resolution == Caps.Resolution) {            
            break;
        }
        Caps.Index++;
    }

    if (Resolution != Caps.Resolution) {
        return RET_OUTOFRANGE;
    }

    if ( Resolution == pIMX322Ctx->Config.Resolution )
    {
        // well, no need to worry
        *pNumberOfFramesToSkip = 0;
    }
    else
    {
        // change resolution
        char *szResName = NULL;
        result = IsiGetResolutionName( Resolution, &szResName );
        TRACE( IMX322_DEBUG, "%s: NewRes=0x%08x (%s)\n", __FUNCTION__, Resolution, szResName);

        // update resolution in copy of config in context
        pIMX322Ctx->Config.Resolution = Resolution;

        // tell sensor about that
        result = IMX322_SetupOutputWindow( pIMX322Ctx, &pIMX322Ctx->Config );
        if ( result != RET_SUCCESS )
        {
            TRACE( IMX322_ERROR, "%s: SetupOutputWindow failed.\n", __FUNCTION__);
            return ( result );
        }

        // remember old exposure values
        float OldGain = pIMX322Ctx->AecCurGain;
        float OldIntegrationTime = pIMX322Ctx->AecCurIntegrationTime;

        // update limits & stuff (reset current & old settings)
        result = IMX322_AecSetModeParameters( pIMX322Ctx, &pIMX322Ctx->Config );
        if ( result != RET_SUCCESS )
        {
            TRACE( IMX322_ERROR, "%s: AecSetModeParameters failed.\n", __FUNCTION__);
            return ( result );
        }

        // restore old exposure values (at least within new exposure values' limits)
        uint8_t NumberOfFramesToSkip = 0;
        float   DummySetGain;
        float   DummySetIntegrationTime;
        result = IMX322_IsiExposureControlIss( handle, OldGain, OldIntegrationTime, &NumberOfFramesToSkip, &DummySetGain, &DummySetIntegrationTime );
        if ( result != RET_SUCCESS )
        {
            TRACE( IMX322_ERROR, "%s: IMX322_IsiExposureControlIss failed.\n", __FUNCTION__);
            return ( result );
        }

        // return number of frames that aren't exposed correctly
        *pNumberOfFramesToSkip = NumberOfFramesToSkip + 1;
    }

    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiSensorSetStreamingIss
 *
 * @brief   Enables/disables streaming of sensor data, if possible.
 *
 * @param   handle      Sensor instance handle
 * @param   on          new streaming state (BOOL_TRUE=on, BOOL_FALSE=off)
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_WRONG_STATE
 *
 *****************************************************************************/
static RESULT IMX322_IsiSensorSetStreamingIss
(
    IsiSensorHandle_t   handle,
    bool_t              on
)
{
    uint32_t RegValue = 0;

    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( (pIMX322Ctx->Configured != BOOL_TRUE) || (pIMX322Ctx->Streaming == on) )
    {
        return RET_WRONG_STATE;
    }
	
    #if 1
    if (on == BOOL_TRUE)
    {
    	TRACE( IMX322_ERROR, "%s stream on\n", __FUNCTION__);
		TRACE( IMX322_ERROR, "Allon %s stream on\n", __FUNCTION__);
        /* enable streaming */
        uint32_t val;
		TRACE( IMX322_ERROR, "S1 %s -----------start-----------------\n", __FUNCTION__);		
			   IMX322_IsiRegReadIss(handle, 0x3000, &val);
			   TRACE( IMX322_ERROR, "%s 0x3000:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0100, &val);
			   TRACE( IMX322_ERROR, "%s 0x0100:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0009, &val);
			   TRACE( IMX322_ERROR, "%s 0x0009:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0101, &val);
			   TRACE( IMX322_ERROR, "%s 0x0101:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0113, &val);
			   TRACE( IMX322_ERROR, "%s 0x0113:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0104, &val);
			   TRACE( IMX322_ERROR, "%s 0x0104:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0340, &val);
			   TRACE( IMX322_ERROR, "%s 0x0340:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0341, &val);
			   TRACE( IMX322_ERROR, "%s 0x0341:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0342, &val);
			   TRACE( IMX322_ERROR, "%s 0x0342:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x0343, &val);
			   TRACE( IMX322_ERROR, "%s 0x0343:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3002, &val);
			   TRACE( IMX322_ERROR, "%s 0x3002:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3011, &val);
			   TRACE( IMX322_ERROR, "%s 0x3011:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3012, &val);
			   TRACE( IMX322_ERROR, "%s 0x3012:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3013, &val);
			   TRACE( IMX322_ERROR, "%s 0x3013:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3016, &val);
			   TRACE( IMX322_ERROR, "%s 0x3016:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x301a, &val);
			   TRACE( IMX322_ERROR, "%s 0x301a:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x301c, &val);
			   TRACE( IMX322_ERROR, "%s 0x301c:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x301f, &val);
			   TRACE( IMX322_ERROR, "%s 0x301f:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3021, &val);
			   TRACE( IMX322_ERROR, "%s 0x3021:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3022, &val);
			   TRACE( IMX322_ERROR, "%s 0x3022:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3027, &val);
			   TRACE( IMX322_ERROR, "%s 0x3027:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x302c, &val);
			   TRACE( IMX322_ERROR, "%s 0x302c:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x303f, &val);
			   TRACE( IMX322_ERROR, "%s 0x303f:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x304f, &val);
			   TRACE( IMX322_ERROR, "%s 0x304f:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3054, &val);
			   TRACE( IMX322_ERROR, "%s 0x3054:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x307a, &val);
			   TRACE( IMX322_ERROR, "%s 0x307a:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x307b, &val);
			   TRACE( IMX322_ERROR, "%s 0x307b:0x%x\n", __FUNCTION__,val);
			   
			   IMX322_IsiRegReadIss(handle, 0x3098, &val);
			   TRACE( IMX322_ERROR, "%s 0x3098:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3099, &val);
			   TRACE( IMX322_ERROR, "%s 0x3099:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x309a, &val);
			   TRACE( IMX322_ERROR, "%s 0x309a:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x309b, &val);
			   TRACE( IMX322_ERROR, "%s 0x309b:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x30ce, &val);
			   TRACE( IMX322_ERROR, "%s 0x30ce:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x30cf, &val);
			   TRACE( IMX322_ERROR, "%s 0x30cf:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x30d0, &val);
			   TRACE( IMX322_ERROR, "%s 0x30d0:0x%x\n", __FUNCTION__,val);
			   
			   IMX322_IsiRegReadIss(handle, 0x3117, &val);
			   TRACE( IMX322_ERROR, "%s 0x3117:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x3000, &val);
			   TRACE( IMX322_ERROR, "%s 0x3000:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x302c, &val);
			   TRACE( IMX322_ERROR, "%s 0x302c:0x%x\n", __FUNCTION__,val);
			   IMX322_IsiRegReadIss(handle, 0x302d, &val);
			   TRACE( IMX322_ERROR, "%s 0x302d:0x%x\n", __FUNCTION__,val);
			   TRACE( IMX322_ERROR, "%s -----------end-----------------\n", __FUNCTION__); 
			   
		//IsiRegDefaultsApply((IsiSensorHandle_t)pIMX322Ctx,IMX322_1920x1080P30);
		//result = IMX322_IsiRegWriteIss( handle, 0x3000, 0x30);
		result = IMX322_IsiRegWriteIss( handle, 0x0100, 0x1);
		//osSleep( 30 );
		
 		TRACE( IMX322_ERROR, " S2 %s -----------start-----------------\n", __FUNCTION__);       
        IMX322_IsiRegReadIss(handle, 0x3000, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3000:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0100, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0100:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0009, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0009:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0101, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0101:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0113, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0113:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0104, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0104:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0340, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0340:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0341, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0341:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0342, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0342:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x0343, &val);
   	   TRACE( IMX322_ERROR, "%s 0x0343:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3002, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3002:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3011, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3011:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3012, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3012:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3013, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3013:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3016, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3016:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x301a, &val);
   	   TRACE( IMX322_ERROR, "%s 0x301a:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x301c, &val);
   	   TRACE( IMX322_ERROR, "%s 0x301c:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x301f, &val);
   	   TRACE( IMX322_ERROR, "%s 0x301f:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3021, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3021:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3022, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3022:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3027, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3027:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x302c, &val);
   	   TRACE( IMX322_ERROR, "%s 0x302c:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x303f, &val);
   	   TRACE( IMX322_ERROR, "%s 0x303f:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x304f, &val);
   	   TRACE( IMX322_ERROR, "%s 0x304f:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3054, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3054:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x307a, &val);
   	   TRACE( IMX322_ERROR, "%s 0x307a:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x307b, &val);
   	   TRACE( IMX322_ERROR, "%s 0x307b:0x%x\n", __FUNCTION__,val);
   	   
   	   IMX322_IsiRegReadIss(handle, 0x3098, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3098:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3099, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3099:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x309a, &val);
   	   TRACE( IMX322_ERROR, "%s 0x309a:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x309b, &val);
   	   TRACE( IMX322_ERROR, "%s 0x309b:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x30ce, &val);
   	   TRACE( IMX322_ERROR, "%s 0x30ce:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x30cf, &val);
   	   TRACE( IMX322_ERROR, "%s 0x30cf:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x30d0, &val);
   	   TRACE( IMX322_ERROR, "%s 0x30d0:0x%x\n", __FUNCTION__,val);
   	   
   	   IMX322_IsiRegReadIss(handle, 0x3117, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3117:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x3000, &val);
   	   TRACE( IMX322_ERROR, "%s 0x3000:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x302c, &val);
   	   TRACE( IMX322_ERROR, "%s 0x302c:0x%x\n", __FUNCTION__,val);
   	   IMX322_IsiRegReadIss(handle, 0x302d, &val);
   	   TRACE( IMX322_ERROR, "%s 0x302d:0x%x\n", __FUNCTION__,val);
		TRACE( IMX322_ERROR, "%s -----------end-----------------\n", __FUNCTION__);	
    }
    else
    {
    #if 1
    TRACE( IMX322_ERROR, "%s stream off\n", __FUNCTION__);
	TRACE( IMX322_ERROR, "Allon %s stream off\n", __FUNCTION__);
	
    /* disable streaming */
    result = IMX322_IsiRegWriteIss( handle, 0x0100, 0x0);
	#endif
    }
    #endif

    if (result == RET_SUCCESS)
    {
        pIMX322Ctx->Streaming = on;
    }

    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiSensorSetPowerIss
 *
 * @brief   Performs the power-up/power-down sequence of the camera, if possible.
 *
 * @param   handle      IMX322 sensor instance handle
 * @param   on          new power state (BOOL_TRUE=on, BOOL_FALSE=off)
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiSensorSetPowerIss
(
    IsiSensorHandle_t   handle,
    bool_t              on
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_INFO, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    pIMX322Ctx->Configured = BOOL_FALSE;
    pIMX322Ctx->Streaming  = BOOL_FALSE;

    TRACE( IMX322_DEBUG, "%s power off \n", __FUNCTION__);
    result = HalSetPower( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, false );
    RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

    TRACE( IMX322_DEBUG, "%s reset on\n", __FUNCTION__);
    result = HalSetReset( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, true );
    RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

    if (on == BOOL_TRUE)
    {
        TRACE( IMX322_DEBUG, "%s power on \n", __FUNCTION__);
		 osSleep( 100 );
        result = HalSetPower( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, true );
        RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

        osSleep( 10 );

        TRACE( IMX322_DEBUG, "%s reset off \n", __FUNCTION__);
        result = HalSetReset( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, false );
        RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

        osSleep( 10 );

        TRACE( IMX322_DEBUG, "%s reset on \n", __FUNCTION__);
        result = HalSetReset( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, true );
        RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

        osSleep( 10 );

        TRACE( IMX322_DEBUG, "%s reset off \n", __FUNCTION__);
        result = HalSetReset( pIMX322Ctx->IsiCtx.HalHandle, pIMX322Ctx->IsiCtx.HalDevID, false );

        osSleep( 50 );
    }

    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiCheckSensorConnectionIss
 *
 * @brief   Checks the I2C-Connection to sensor by reading sensor revision id.
 *
 * @param   handle      IMX322 sensor instance handle
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiCheckSensorConnectionIss
(
    IsiSensorHandle_t   handle
)
{
    uint32_t RevId;
    uint32_t value;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( handle == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }
#if 1
    RevId = IMX322_CHIP_ID_HIGH_BYTE_DEFAULT;

    result = IMX322_IsiGetSensorRevisionIss( handle, &value );
    if ( (result != RET_SUCCESS) || (RevId != value) )
    {
        TRACE( IMX322_ERROR, "%s RevId = 0x%08x, value = 0x%08x \n", __FUNCTION__, RevId, value );
        return ( RET_FAILURE );
    }

    TRACE( IMX322_DEBUG, "%s RevId = 0x%08x, value = 0x%08x \n", __FUNCTION__, RevId, value );
#endif
    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetSensorRevisionIss
 *
 * @brief   reads the sensor revision register and returns this value
 *
 * @param   handle      pointer to sensor description struct
 * @param   p_value     pointer to storage value
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetSensorRevisionIss
(
    IsiSensorHandle_t   handle,
    uint32_t            *p_value
)
{
    RESULT result = RET_SUCCESS;

    uint32_t data;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_INFO, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( handle == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( p_value == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *p_value = 0U;
    result = IMX322_IsiRegReadIss ( handle, IMX322_CHIP_ID_HIGH_BYTE, &data );
    *p_value |= ( (data & 0xFF));

    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiRegReadIss
 *
 * @brief   grants user read access to the camera register
 *
 * @param   handle      pointer to sensor description struct
 * @param   address     sensor register to write
 * @param   p_value     pointer to value
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiRegReadIss
(
    IsiSensorHandle_t   handle,
    const uint32_t      address,
    uint32_t            *p_value
)
{
    RESULT result = RET_SUCCESS;

  //  TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);

    if ( handle == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( p_value == NULL )
    {
        return ( RET_NULL_POINTER );
    }
    else
    {
        uint8_t NrOfBytes = IsiGetNrDatBytesIss( address, IMX322_g_aRegDescription );
        if ( !NrOfBytes )
        {
            NrOfBytes = 1;
        }
 //       TRACE( IMX322_REG_DEBUG, "%s (IsiGetNrDatBytesIss %d 0x%08x)\n", __FUNCTION__, NrOfBytes, address);

        *p_value = 0;
        result = IsiI2cReadSensorRegister( handle, address, (uint8_t *)p_value, NrOfBytes, BOOL_TRUE );
    }

  //  TRACE( IMX322_INFO, "%s (exit: 0x%08x 0x%08x)\n", __FUNCTION__, address, *p_value);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiRegWriteIss
 *
 * @brief   grants user write access to the camera register
 *
 * @param   handle      pointer to sensor description struct
 * @param   address     sensor register to write
 * @param   value       value to write
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 *
 *****************************************************************************/
static RESULT IMX322_IsiRegWriteIss
(
    IsiSensorHandle_t   handle,
    const uint32_t      address,
    const uint32_t      value
)
{
    RESULT result = RET_SUCCESS;

    uint8_t NrOfBytes;

  //  TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);

    if ( handle == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    NrOfBytes = IsiGetNrDatBytesIss( address, IMX322_g_aRegDescription );
    if ( !NrOfBytes )
    {
        NrOfBytes = 1;
    }
//    TRACE( IMX322_REG_DEBUG, "%s (IsiGetNrDatBytesIss %d 0x%08x 0x%08x)\n", __FUNCTION__, NrOfBytes, address, value);

    result = IsiI2cWriteSensorRegister( handle, address, (uint8_t *)(&value), NrOfBytes, BOOL_TRUE );

//    TRACE( IMX322_INFO, "%s (exit: 0x%08x 0x%08x)\n", __FUNCTION__, address, value);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetGainLimitsIss
 *
 * @brief   Returns the exposure minimal and maximal values of an
 *          IMX322 instance
 *
 * @param   handle       IMX322 sensor instance handle
 * @param   pMinExposure Pointer to a variable receiving minimal exposure value
 * @param   pMaxExposure Pointer to a variable receiving maximal exposure value
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetGainLimitsIss
(
    IsiSensorHandle_t   handle,
    float               *pMinGain,
    float               *pMaxGain
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    uint32_t RegValue = 0;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif 
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( (pMinGain == NULL) || (pMaxGain == NULL) )
    {
        TRACE( IMX322_ERROR, "%s: NULL pointer received!!\n" );
        return ( RET_NULL_POINTER );
    }

    *pMinGain = pIMX322Ctx->AecMinGain;
    *pMaxGain = pIMX322Ctx->AecMaxGain;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetIntegrationTimeLimitsIss
 *
 * @brief   Returns the minimal and maximal integration time values of an
 *          IMX322 instance
 *
 * @param   handle       IMX322 sensor instance handle
 * @param   pMinExposure Pointer to a variable receiving minimal exposure value
 * @param   pMaxExposure Pointer to a variable receiving maximal exposure value
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetIntegrationTimeLimitsIss
(
    IsiSensorHandle_t   handle,
    float               *pMinIntegrationTime,
    float               *pMaxIntegrationTime
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    uint32_t RegValue = 0;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( (pMinIntegrationTime == NULL) || (pMaxIntegrationTime == NULL) )
    {
        TRACE( IMX322_ERROR, "%s: NULL pointer received!!\n" );
        return ( RET_NULL_POINTER );
    }

    *pMinIntegrationTime = pIMX322Ctx->AecMinIntegrationTime;
    *pMaxIntegrationTime = pIMX322Ctx->AecMaxIntegrationTime;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);

    return ( result );
}


/*****************************************************************************/
/**
 *          IMX322_IsiGetGainIss
 *
 * @brief   Reads gain values from the image sensor module.
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   pSetGain                set gain
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_IsiGetGainIss
(
    IsiSensorHandle_t   handle,
    float               *pSetGain
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pSetGain == NULL)
    {
        return ( RET_NULL_POINTER );
    }

    *pSetGain = pIMX322Ctx->AecCurGain;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetGainIncrementIss
 *
 * @brief   Get smallest possible gain increment.
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   pIncr                   increment
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_IsiGetGainIncrementIss
(
    IsiSensorHandle_t   handle,
    float               *pIncr
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif 
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pIncr == NULL)
    {
        return ( RET_NULL_POINTER );
    }

    //_smallest_ increment the sensor/driver can handle (e.g. used for sliders in the application)
    *pIncr = pIMX322Ctx->AecGainIncrement;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiSetGainIss
 *
 * @brief   Writes gain values to the image sensor module.
 *          Updates current gain and exposure in sensor struct/state.
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   NewGain                 gain to be set
 * @param   pSetGain                set gain
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 * @retval  RET_INVALID_PARM
 * @retval  RET_FAILURE
 *
 *****************************************************************************/
RESULT IMX322_IsiSetGainIss
(
    IsiSensorHandle_t   handle,
    float               NewGain,
    float               *pSetGain
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    uint16_t usGain = 0;
	uint16_t resultGain = 0;
	float y = 0;
    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pSetGain == NULL)
    {
        TRACE( IMX322_ERROR, "%s: Invalid parameter (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_NULL_POINTER );
    }

  
    if( NewGain < pIMX322Ctx->AecMinGain ) NewGain = pIMX322Ctx->AecMinGain;
    if( NewGain > pIMX322Ctx->AecMaxGain ) NewGain = pIMX322Ctx->AecMaxGain;
	// db = 20 * lg(gain);
	//y = pow(10, NewGain/20);
	y = 20 * log10(NewGain);
    usGain = (uint16_t)(y * 10);

	resultGain = usGain / 3;

    // write new gain into sensor registers, do not write if nothing has changed
    if( (usGain != pIMX322Ctx->OldGain) )
    {
		//result = IMX322_IsiRegWriteIss( handle, 0x301e, resultGain);
		result = IMX322_IsiRegWriteIss( handle, 0x301e, 4);
		RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );
        pIMX322Ctx->OldGain = usGain;
    }

    //calculate gain actually set
    //pIMX322Ctx->AecCurGain = (float)usGain / 10.0f;

	pIMX322Ctx->AecCurGain = pow(10, y/20);

    //return current state
    *pSetGain = pIMX322Ctx->AecCurGain;
    TRACE( IMX322_INFO, "%s:NewGain:%f pSetGain:%f gain_db:%f resultGain:%x\n", __FUNCTION__, NewGain, *pSetGain, y, resultGain);

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetIntegrationTimeIss
 *
 * @brief   Reads integration time values from the image sensor module.
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   pSetIntegrationTime     set integration time
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_IsiGetIntegrationTimeIss
(
    IsiSensorHandle_t   handle,
    float               *pSetIntegrationTime
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pSetIntegrationTime == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *pSetIntegrationTime = pIMX322Ctx->AecCurIntegrationTime;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetIntegrationTimeIncrementIss
 *
 * @brief   Get smallest possible integration time increment.
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   pIncr                   increment
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_IsiGetIntegrationTimeIncrementIss
(
    IsiSensorHandle_t   handle,
    float               *pIncr
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
	
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pIncr == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    //_smallest_ increment the sensor/driver can handle (e.g. used for sliders in the application)
    *pIncr = pIMX322Ctx->AecIntegrationTimeIncrement;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiSetIntegrationTimeIss
 *
 * @brief   Writes gain and integration time values to the image sensor module.
 *          Updates current integration time and exposure in sensor
 *          struct/state.
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   NewIntegrationTime      integration time to be set
 * @param   pSetIntegrationTime     set integration time
 * @param   pNumberOfFramesToSkip   number of frames to skip until AE is
 *                                  executed again
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 * @retval  RET_INVALID_PARM
 * @retval  RET_FAILURE
 * @retval  RET_DIVISION_BY_ZERO
 *
 *****************************************************************************/
RESULT IMX322_IsiSetIntegrationTimeIss
(
    IsiSensorHandle_t   handle,
    float               NewIntegrationTime,
    float               *pSetIntegrationTime,
    uint8_t             *pNumberOfFramesToSkip
)
{
	/* Integration time = (1 frame period) - (INTEG_TIME)*(1H period) - 0.3[H]   */
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

	uint32_t CoarseIntegrationTime = 0;
	float ShutterWidthPck = 0.0f;
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
	if (pIMX322Ctx == NULL)
	{
		TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
		return ( RET_WRONG_HANDLE );
	}
	
	if ( (pSetIntegrationTime == NULL) || (pNumberOfFramesToSkip == NULL) )
	{
		TRACE( IMX322_ERROR, "%s: Invalid parameter (NULL pointer detected)\n", __FUNCTION__ );
		return ( RET_NULL_POINTER );
	}

	TRACE( IMX322_INFO, "%s: (enter) NewIntegrationTime: %f (min: %f   max: %f)\n", __FUNCTION__,
		NewIntegrationTime,
		pIMX322Ctx->AecMinIntegrationTime,
		pIMX322Ctx->AecMaxIntegrationTime);
	
	if ( NewIntegrationTime > pIMX322Ctx->AecMaxIntegrationTime ) NewIntegrationTime = pIMX322Ctx->AecMaxIntegrationTime;
	if ( NewIntegrationTime < pIMX322Ctx->AecMinIntegrationTime ) NewIntegrationTime = pIMX322Ctx->AecMinIntegrationTime;

	if ( pIMX322Ctx->LineLengthPck == 0 )
	{
		TRACE( IMX322_ERROR, "%s: Division by zero!\n", __FUNCTION__ );
		return ( RET_DIVISION_BY_ZERO );
	}

	ShutterWidthPck = NewIntegrationTime * (float)pIMX322Ctx->VtPixClkFreq + (0.3 * (float)pIMX322Ctx->LineLengthPck);

	CoarseIntegrationTime = (uint32_t)( (((float)pIMX322Ctx->LineLengthPck * (float)pIMX322Ctx->FrameLengthLines) -  ShutterWidthPck) / ((float)pIMX322Ctx->LineLengthPck) + 0.5f );

	if( CoarseIntegrationTime != pIMX322Ctx->OldCoarseIntegrationTime )
	{
#if 0
		result = IMX322_IsiRegWriteIss( pIMX322Ctx, 0x0202, (CoarseIntegrationTime & 0xff00) >> 8 );
		RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );
		result = IMX322_IsiRegWriteIss( pIMX322Ctx, 0x0203, (CoarseIntegrationTime & 0xff));
#else
		result = IMX322_IsiRegWriteIss( pIMX322Ctx, 0x0202,  0x09);
		RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );
		result = IMX322_IsiRegWriteIss( pIMX322Ctx, 0x0203, 0xc4);
#endif
		RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

		pIMX322Ctx->OldCoarseIntegrationTime = CoarseIntegrationTime;
		*pNumberOfFramesToSkip = 1U;
	}
	else
	{
		*pNumberOfFramesToSkip = 0U;
	}

	pIMX322Ctx->AecCurIntegrationTime = ((float)pIMX322Ctx->FrameLengthLines - (float)CoarseIntegrationTime - 0.3) * ((float)pIMX322Ctx->LineLengthPck) / pIMX322Ctx->VtPixClkFreq;
	*pSetIntegrationTime = pIMX322Ctx->AecCurIntegrationTime;

    TRACE( IMX322_INFO, "%s: Ti=%f TimeReg:%d\n", __FUNCTION__, *pSetIntegrationTime, CoarseIntegrationTime);
    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}




/*****************************************************************************/
/**
 *          IMX322_IsiExposureControlIss
 *
 * @brief   Camera hardware dependent part of the exposure control loop.
 *          Calculates appropriate register settings from the new exposure
 *          values and writes them to the image sensor module.
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   NewGain                 newly calculated gain to be set
 * @param   NewIntegrationTime      newly calculated integration time to be set
 * @param   pNumberOfFramesToSkip   number of frames to skip until AE is
 *                                  executed again
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 * @retval  RET_INVALID_PARM
 * @retval  RET_FAILURE
 * @retval  RET_DIVISION_BY_ZERO
 *
 *****************************************************************************/
RESULT IMX322_IsiExposureControlIss
(
    IsiSensorHandle_t   handle,
    float               NewGain,
    float               NewIntegrationTime,
    uint8_t             *pNumberOfFramesToSkip,
    float               *pSetGain,
    float               *pSetIntegrationTime
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( (pNumberOfFramesToSkip == NULL)
            || (pSetGain == NULL)
            || (pSetIntegrationTime == NULL) )
    {
        TRACE( IMX322_ERROR, "%s: Invalid parameter (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_NULL_POINTER );
    }

    TRACE( IMX322_DEBUG, "%s: g=%f, Ti=%f\n", __FUNCTION__, NewGain, NewIntegrationTime );

    result = IMX322_IsiSetIntegrationTimeIss( handle, NewIntegrationTime, pSetIntegrationTime, pNumberOfFramesToSkip );
    result = IMX322_IsiSetGainIss( handle, NewGain, pSetGain );
	*pNumberOfFramesToSkip = 2;

    TRACE( IMX322_DEBUG, "%s: set: g=%f, Ti=%f, skip=%d\n", __FUNCTION__, *pSetGain, *pSetIntegrationTime, *pNumberOfFramesToSkip );
    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCurrentExposureIss
 *
 * @brief   Returns the currently adjusted AE values
 *
 * @param   handle                  IMX322 sensor instance handle
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_IsiGetCurrentExposureIss
(
    IsiSensorHandle_t   handle,
    float               *pSetGain,
    float               *pSetIntegrationTime
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    uint32_t RegValue = 0;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( (pSetGain == NULL) || (pSetIntegrationTime == NULL) )
    {
        return ( RET_NULL_POINTER );
    }

    *pSetGain            = pIMX322Ctx->AecCurGain;
    *pSetIntegrationTime = pIMX322Ctx->AecCurIntegrationTime;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetResolutionIss
 *
 * @brief   Reads integration time values from the image sensor module.
 *
 * @param   handle                  sensor instance handle
 * @param   pSettResolution         set resolution
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_IsiGetResolutionIss
(
    IsiSensorHandle_t   handle,
    uint32_t            *pSetResolution
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pSetResolution == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *pSetResolution = pIMX322Ctx->Config.Resolution;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetAfpsInfoHelperIss
 *
 * @brief   Calc AFPS sub resolution settings for the given resolution
 *
 * @param   pIMX322Ctx             IMX322 sensor instance (dummy!) context
 * @param   Resolution              Any supported resolution to query AFPS params for
 * @param   pAfpsInfo               Reference of AFPS info structure to write the results to
 * @param   AfpsStageIdx            Index of current AFPS stage to use
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetAfpsInfoHelperIss(
    IMX322_Context_t   *pIMX322Ctx,
    uint32_t            Resolution,
    IsiAfpsInfo_t*      pAfpsInfo,
    uint32_t            AfpsStageIdx
)
{
    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    DCT_ASSERT(pIMX322Ctx != NULL);
    DCT_ASSERT(pAfpsInfo != NULL);
    DCT_ASSERT(AfpsStageIdx <= ISI_NUM_AFPS_STAGES);

    // update resolution in copy of config in context
    pIMX322Ctx->Config.Resolution = Resolution;

    // tell sensor about that
    result = IMX322_SetupOutputWindow( pIMX322Ctx, &pIMX322Ctx->Config );
    if ( result != RET_SUCCESS )
    {
        TRACE( IMX322_ERROR, "%s: SetupOutputWindow failed for resolution ID %08x.\n", __FUNCTION__, Resolution);
        return ( result );
    }

    // update limits & stuff (reset current & old settings)
    result = IMX322_AecSetModeParameters( pIMX322Ctx, &pIMX322Ctx->Config );
    if ( result != RET_SUCCESS )
    {
        TRACE( IMX322_ERROR, "%s: AecSetModeParameters failed for resolution ID %08x.\n", __FUNCTION__, Resolution);
        return ( result );
    }

    // take over params
    pAfpsInfo->Stage[AfpsStageIdx].Resolution = Resolution;
    pAfpsInfo->Stage[AfpsStageIdx].MaxIntTime = pIMX322Ctx->AecMaxIntegrationTime;
    pAfpsInfo->AecMinGain           = pIMX322Ctx->AecMinGain;
    pAfpsInfo->AecMaxGain           = pIMX322Ctx->AecMaxGain;
    pAfpsInfo->AecMinIntTime        = pIMX322Ctx->AecMinIntegrationTime;
    pAfpsInfo->AecMaxIntTime        = pIMX322Ctx->AecMaxIntegrationTime;
    pAfpsInfo->AecSlowestResolution = Resolution;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}

/*****************************************************************************/
/**
 *          IMX322_IsiGetAfpsInfoIss
 *
 * @brief   Returns the possible AFPS sub resolution settings for the given resolution series
 *
 * @param   handle                  IMX322 sensor instance handle
 * @param   Resolution              Any resolution within the AFPS group to query;
 *                                  0 (zero) to use the currently configured resolution
 * @param   pAfpsInfo               Reference of AFPS info structure to store the results
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 * @retval  RET_NOTSUPP
 *
 *****************************************************************************/
RESULT IMX322_IsiGetAfpsInfoIss(
    IsiSensorHandle_t   handle,
    uint32_t            Resolution,
    IsiAfpsInfo_t*      pAfpsInfo
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    uint32_t RegValue = 0;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
	
    if ( pIMX322Ctx == NULL )
    {
        TRACE( IMX322_ERROR, "%s: Invalid sensor handle (NULL pointer detected)\n", __FUNCTION__ );
        return ( RET_WRONG_HANDLE );
    }

    if ( pAfpsInfo == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    // use currently configured resolution?
    if (Resolution == 0)
    {
        Resolution = pIMX322Ctx->Config.Resolution;
    }

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCalibKFactor
 *
 * @brief   Returns the IMX322 specific K-Factor
 *
 * @param   handle       IMX322 sensor instance handle
 * @param   pIsiKFactor  Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCalibKFactor
(
    IsiSensorHandle_t   handle,
    Isi1x1FloatMatrix_t **pIsiKFactor
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( pIsiKFactor == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *pIsiKFactor = NULL;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}


/*****************************************************************************/
/**
 *          IMX322_IsiGetCalibPcaMatrix
 *
 * @brief   Returns the IMX322 specific PCA-Matrix
 *
 * @param   handle          IMX322 sensor instance handle
 * @param   pIsiPcaMatrix   Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCalibPcaMatrix
(
    IsiSensorHandle_t   handle,
    Isi3x2FloatMatrix_t **pIsiPcaMatrix
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
    #endif
	
    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( pIsiPcaMatrix == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *pIsiPcaMatrix = NULL;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCalibSvdMeanValue
 *
 * @brief   Returns the sensor specific SvdMean-Vector
 *
 * @param   handle              IMX322 sensor instance handle
 * @param   pIsiSvdMeanValue    Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCalibSvdMeanValue
(
    IsiSensorHandle_t   handle,
    Isi3x1FloatMatrix_t **pIsiSvdMeanValue
)
{
    IsiSensorContext_t *pSensorCtx = (IsiSensorContext_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
    #endif
	
    if ( pSensorCtx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( pIsiSvdMeanValue == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *pIsiSvdMeanValue = NULL;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCalibSvdMeanValue
 *
 * @brief   Returns a pointer to the sensor specific centerline, a straight
 *          line in Hesse normal form in Rg/Bg colorspace
 *
 * @param   handle              IMX322 sensor instance handle
 * @param   pIsiSvdMeanValue    Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCalibCenterLine
(
    IsiSensorHandle_t   handle,
    IsiLine_t           **ptIsiCenterLine
)
{
    IsiSensorContext_t *pSensorCtx = (IsiSensorContext_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pSensorCtx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( ptIsiCenterLine == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *ptIsiCenterLine = NULL;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCalibClipParam
 *
 * @brief   Returns a pointer to the sensor specific arrays for Rg/Bg color
 *          space clipping
 *
 * @param   handle              IMX322 sensor instance handle
 * @param   pIsiSvdMeanValue    Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCalibClipParam
(
    IsiSensorHandle_t   handle,
    IsiAwbClipParm_t    **pIsiClipParam
)
{
    IsiSensorContext_t *pSensorCtx = (IsiSensorContext_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pSensorCtx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( pIsiClipParam == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *pIsiClipParam = NULL;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCalibGlobalFadeParam
 *
 * @brief   Returns a pointer to the sensor specific arrays for AWB out of
 *          range handling
 *
 * @param   handle              IMX322 sensor instance handle
 * @param   pIsiSvdMeanValue    Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCalibGlobalFadeParam
(
    IsiSensorHandle_t       handle,
    IsiAwbGlobalFadeParm_t  **ptIsiGlobalFadeParam
)
{
    IsiSensorContext_t *pSensorCtx = (IsiSensorContext_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pSensorCtx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( ptIsiGlobalFadeParam == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *ptIsiGlobalFadeParam = NULL;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetCalibFadeParam
 *
 * @brief   Returns a pointer to the sensor specific arrays for near white
 *          pixel parameter calculations
 *
 * @param   handle              IMX322 sensor instance handle
 * @param   pIsiSvdMeanValue    Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetCalibFadeParam
(
    IsiSensorHandle_t   handle,
    IsiAwbFade2Parm_t   **ptIsiFadeParam
)
{
    IsiSensorContext_t *pSensorCtx = (IsiSensorContext_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pSensorCtx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( ptIsiFadeParam == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    *ptIsiFadeParam = NULL;

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}

/*****************************************************************************/
/**
 *          IMX322_IsiGetIlluProfile
 *
 * @brief   Returns a pointer to illumination profile idetified by CieProfile
 *          bitmask
 *
 * @param   handle              sensor instance handle
 * @param   CieProfile
 * @param   ptIsiIlluProfile    Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetIlluProfile
(
    IsiSensorHandle_t   handle,
    const uint32_t      CieProfile,
    IsiIlluProfile_t    **ptIsiIlluProfile
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( ptIsiIlluProfile == NULL )
    {
        return ( RET_NULL_POINTER );
    }
    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetLscMatrixTable
 *
 * @brief   Returns a pointer to illumination profile idetified by CieProfile
 *          bitmask
 *
 * @param   handle              sensor instance handle
 * @param   CieProfile
 * @param   ptIsiIlluProfile    Pointer to Pointer receiving the memory address
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiGetLscMatrixTable
(
    IsiSensorHandle_t   handle,
    const uint32_t      CieProfile,
    IsiLscMatrixTable_t **pLscMatrixTable
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( pLscMatrixTable == NULL )
    {
        return ( RET_NULL_POINTER );
    }
    else

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}


/*****************************************************************************/
/**
 *          IMX322_IsiMdiInitMotoDriveMds
 *
 * @brief   General initialisation tasks like I/O initialisation.
 *
 * @param   handle              IMX322 sensor instance handle
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiMdiInitMotoDriveMds
(
    IsiSensorHandle_t   handle
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
#if ALLON_DEBUG_ENABLE

	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiMdiSetupMotoDrive
 *
 * @brief   Setup of the MotoDrive and return possible max step.
 *
 * @param   handle          IMX322 sensor instance handle
 *          pMaxStep        pointer to variable to receive the maximum
 *                          possible focus step
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiMdiSetupMotoDrive
(
    IsiSensorHandle_t   handle,
    uint32_t            *pMaxStep
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif
    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( pMaxStep == NULL )
    {
        return ( RET_NULL_POINTER );
    }


    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiMdiFocusSet
 *
 * @brief   Drives the lens system to a certain focus point.
 *
 * @param   handle          IMX322 sensor instance handle
 *          AbsStep         absolute focus point to apply
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiMdiFocusSet
(
    IsiSensorHandle_t   handle,
    const uint32_t      Position
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    uint32_t nPosition;
    uint8_t  data[2] = { 0, 0 };

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR,"Allon %s (enter)",__FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }
    RETURN_RESULT_IF_DIFFERENT( RET_SUCCESS, result );

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiMdiFocusGet
 *
 * @brief   Retrieves the currently applied focus point.
 *
 * @param   handle          IMX322 sensor instance handle
 *          pAbsStep        pointer to a variable to receive the current
 *                          focus point
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiMdiFocusGet
(
    IsiSensorHandle_t   handle,
    uint32_t            *pAbsStep
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;
    uint8_t  data[2] = { 0, 0 };

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    if ( pAbsStep == NULL )
    {
        return ( RET_NULL_POINTER );
    }

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiMdiFocusCalibrate
 *
 * @brief   Triggers a forced calibration of the focus hardware.
 *
 * @param   handle          IMX322 sensor instance handle
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
static RESULT IMX322_IsiMdiFocusCalibrate
(
    IsiSensorHandle_t   handle
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiActivateTestPattern
 *
 * @brief   Triggers a forced calibration of the focus hardware.
 *
 * @param   handle          IMX322 sensor instance handle
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 ******************************************************************************/
static RESULT IMX322_IsiActivateTestPattern
(
    IsiSensorHandle_t   handle,
    const bool_t        enable
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    RESULT result = RET_SUCCESS;

    return ( result );
}



/*****************************************************************************/
/**
 *          IMX322_IsiGetSensorMipiInfoIss
 *
 * @brief   Triggers a forced calibration of the focus hardware.
 *
 * @param   handle          IMX322 sensor instance handle
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_WRONG_HANDLE
 * @retval  RET_NULL_POINTER
 *
 ******************************************************************************/
static RESULT IMX322_IsiGetSensorMipiInfoIss
(
    IsiSensorHandle_t   handle,
    IsiSensorMipiInfo   *ptIsiSensorMipiInfo
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
        return ( RET_WRONG_HANDLE );
    }


    if ( ptIsiSensorMipiInfo == NULL )
    {
        return ( result );
    }

    TRACE( IMX322_INFO, "%s: (exit)\n", __FUNCTION__);

    return ( result );
}

static RESULT IMX322_IsiGetSensorIsiVersion
(  IsiSensorHandle_t   handle,
   unsigned int*     pVersion
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;


    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
    	TRACE( IMX322_ERROR, "%s: pIMX322Ctx IS NULL\n", __FUNCTION__);
        return ( RET_WRONG_HANDLE );
    }

	if(pVersion == NULL)
	{
		TRACE( IMX322_ERROR, "%s: pVersion IS NULL\n", __FUNCTION__);
        return ( RET_WRONG_HANDLE );
	}

	*pVersion = CONFIG_ISI_VERSION;
	return result;
}

static RESULT IMX322_IsiGetSensorTuningXmlVersion
(  IsiSensorHandle_t   handle,
   char**     pTuningXmlVersion
)
{
    IMX322_Context_t *pIMX322Ctx = (IMX322_Context_t *)handle;

    RESULT result = RET_SUCCESS;


    TRACE( IMX322_INFO, "%s: (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_ERROR, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIMX322Ctx == NULL )
    {
    	TRACE( IMX322_ERROR, "%s: pIMX322Ctx IS NULL\n", __FUNCTION__);
        return ( RET_WRONG_HANDLE );
    }

	if(pTuningXmlVersion == NULL)
	{
		TRACE( IMX322_ERROR, "%s: pVersion IS NULL\n", __FUNCTION__);
        return ( RET_WRONG_HANDLE );
	}

	*pTuningXmlVersion = IMX322_NEWEST_TUNING_XML;
	return result;
}

/*****************************************************************************/
/**
 *          IMX322_IsiGetSensorIss
 *
 * @brief   fills in the correct pointers for the sensor description struct
 *
 * @param   param1      pointer to sensor description struct
 *
 * @return  Return the result of the function call.
 * @retval  RET_SUCCESS
 * @retval  RET_NULL_POINTER
 *
 *****************************************************************************/
RESULT IMX322_IsiGetSensorIss
(
    IsiSensor_t *pIsiSensor
)
{
    RESULT result = RET_SUCCESS;

    TRACE( IMX322_INFO, "%s (enter)\n", __FUNCTION__);
	#if ALLON_DEBUG_ENABLE
	TRACE( IMX322_INFO, "Allon %s (enter)\n", __FUNCTION__);
	#endif

    if ( pIsiSensor != NULL )
    {
        pIsiSensor->pszName                             = IMX322_g_acName;
        pIsiSensor->pRegisterTable                      = IMX322_g_aRegDescription;
        pIsiSensor->pIsiSensorCaps                      = &IMX322_g_IsiSensorDefaultConfig;
		pIsiSensor->pIsiGetSensorIsiVer					= IMX322_IsiGetSensorIsiVersion;
		pIsiSensor->pIsiGetSensorTuningXmlVersion		= IMX322_IsiGetSensorTuningXmlVersion;//oyyf

        pIsiSensor->pIsiCreateSensorIss                 = IMX322_IsiCreateSensorIss;
        pIsiSensor->pIsiReleaseSensorIss                = IMX322_IsiReleaseSensorIss;
        pIsiSensor->pIsiGetCapsIss                      = IMX322_IsiGetCapsIss;
        pIsiSensor->pIsiSetupSensorIss                  = IMX322_IsiSetupSensorIss;
        pIsiSensor->pIsiChangeSensorResolutionIss       = IMX322_IsiChangeSensorResolutionIss;
        pIsiSensor->pIsiSensorSetStreamingIss           = IMX322_IsiSensorSetStreamingIss;
        pIsiSensor->pIsiSensorSetPowerIss               = IMX322_IsiSensorSetPowerIss;
        pIsiSensor->pIsiCheckSensorConnectionIss        = IMX322_IsiCheckSensorConnectionIss;
        pIsiSensor->pIsiGetSensorRevisionIss            = IMX322_IsiGetSensorRevisionIss;
        pIsiSensor->pIsiRegisterReadIss                 = IMX322_IsiRegReadIss;
        pIsiSensor->pIsiRegisterWriteIss                = IMX322_IsiRegWriteIss;

        /* AEC functions */
        pIsiSensor->pIsiExposureControlIss              = IMX322_IsiExposureControlIss;
        pIsiSensor->pIsiGetGainLimitsIss                = IMX322_IsiGetGainLimitsIss;
        pIsiSensor->pIsiGetIntegrationTimeLimitsIss     = IMX322_IsiGetIntegrationTimeLimitsIss;
        pIsiSensor->pIsiGetCurrentExposureIss           = IMX322_IsiGetCurrentExposureIss;
        pIsiSensor->pIsiGetGainIss                      = IMX322_IsiGetGainIss;
        pIsiSensor->pIsiGetGainIncrementIss             = IMX322_IsiGetGainIncrementIss;
        pIsiSensor->pIsiSetGainIss                      = IMX322_IsiSetGainIss;
        pIsiSensor->pIsiGetIntegrationTimeIss           = IMX322_IsiGetIntegrationTimeIss;
        pIsiSensor->pIsiGetIntegrationTimeIncrementIss  = IMX322_IsiGetIntegrationTimeIncrementIss;
        pIsiSensor->pIsiSetIntegrationTimeIss           = IMX322_IsiSetIntegrationTimeIss;
        pIsiSensor->pIsiGetResolutionIss                = IMX322_IsiGetResolutionIss;
        pIsiSensor->pIsiGetAfpsInfoIss                  = IMX322_IsiGetAfpsInfoIss;

        /* AWB specific functions */
        pIsiSensor->pIsiGetCalibKFactor                 = IMX322_IsiGetCalibKFactor;
        pIsiSensor->pIsiGetCalibPcaMatrix               = IMX322_IsiGetCalibPcaMatrix;
        pIsiSensor->pIsiGetCalibSvdMeanValue            = IMX322_IsiGetCalibSvdMeanValue;
        pIsiSensor->pIsiGetCalibCenterLine              = IMX322_IsiGetCalibCenterLine;
        pIsiSensor->pIsiGetCalibClipParam               = IMX322_IsiGetCalibClipParam;
        pIsiSensor->pIsiGetCalibGlobalFadeParam         = IMX322_IsiGetCalibGlobalFadeParam;
        pIsiSensor->pIsiGetCalibFadeParam               = IMX322_IsiGetCalibFadeParam;
        pIsiSensor->pIsiGetIlluProfile                  = IMX322_IsiGetIlluProfile;
        pIsiSensor->pIsiGetLscMatrixTable               = IMX322_IsiGetLscMatrixTable;

        /* AF functions */
        pIsiSensor->pIsiMdiInitMotoDriveMds             = IMX322_IsiMdiInitMotoDriveMds;
        pIsiSensor->pIsiMdiSetupMotoDrive               = IMX322_IsiMdiSetupMotoDrive;
        pIsiSensor->pIsiMdiFocusSet                     = IMX322_IsiMdiFocusSet;
        pIsiSensor->pIsiMdiFocusGet                     = IMX322_IsiMdiFocusGet;
        pIsiSensor->pIsiMdiFocusCalibrate               = IMX322_IsiMdiFocusCalibrate;

        /* MIPI */
        pIsiSensor->pIsiGetSensorMipiInfoIss            = IMX322_IsiGetSensorMipiInfoIss;

        /* Testpattern */
        pIsiSensor->pIsiActivateTestPattern             = IMX322_IsiActivateTestPattern;
    }
    else
    {
        result = RET_NULL_POINTER;
    }

    TRACE( IMX322_INFO, "%s (exit)\n", __FUNCTION__);

    return ( result );
}

static RESULT IMX322_IsiGetSensorI2cInfo(sensor_i2c_info_t** pdata)
{
    sensor_i2c_info_t* pSensorI2cInfo;

    pSensorI2cInfo = ( sensor_i2c_info_t * )malloc ( sizeof (sensor_i2c_info_t) );

    if ( pSensorI2cInfo == NULL )
    {
        TRACE( IMX322_ERROR,  "%s: Can't allocate ov14825 context\n",  __FUNCTION__ );
        return ( RET_OUTOFMEM );
    }
    MEMSET( pSensorI2cInfo, 0, sizeof( sensor_i2c_info_t ) );

    
    pSensorI2cInfo->i2c_addr = IMX322_SLAVE_ADDR;
    pSensorI2cInfo->i2c_addr2 = IMX322_SLAVE_ADDR2;
    pSensorI2cInfo->soft_reg_addr = IMX322_SOFTWARE_RST;
    pSensorI2cInfo->soft_reg_value = 0x00;
    pSensorI2cInfo->reg_size = IMX322_I2C_NR_ADR_BYTES;
    pSensorI2cInfo->value_size = IMX322_I2C_NR_DAT_BYTES;

    {
        IsiSensorCaps_t Caps;
        sensor_caps_t *pCaps;
        uint32_t lanes,i;
        
        ListInit(&pSensorI2cInfo->lane_res[0]);
        ListInit(&pSensorI2cInfo->lane_res[1]);
        ListInit(&pSensorI2cInfo->lane_res[2]);
        
        Caps.Index = 0;            
        while(IMX322_IsiGetCapsIssInternal(&Caps)==RET_SUCCESS) {
            pCaps = malloc(sizeof(sensor_caps_t));
            if (pCaps != NULL) {
                memcpy(&pCaps->caps,&Caps,sizeof(IsiSensorCaps_t));
                ListPrepareItem(pCaps);
                ListAddTail(&pSensorI2cInfo->lane_res[0], pCaps);
            }
            Caps.Index++;
        }
    }
    
    ListInit(&pSensorI2cInfo->chipid_info);

    sensor_chipid_info_t* pChipIDInfo_H = (sensor_chipid_info_t *) malloc( sizeof(sensor_chipid_info_t) );
    if ( !pChipIDInfo_H )
    {
        return RET_OUTOFMEM;
    }
    MEMSET( pChipIDInfo_H, 0, sizeof(*pChipIDInfo_H) );    
    pChipIDInfo_H->chipid_reg_addr = IMX322_CHIP_ID_HIGH_BYTE;  
    pChipIDInfo_H->chipid_reg_value = IMX322_CHIP_ID_HIGH_BYTE_DEFAULT;
    ListPrepareItem( pChipIDInfo_H );
    ListAddTail( &pSensorI2cInfo->chipid_info, pChipIDInfo_H );

	//oyyf sensor drv version
	pSensorI2cInfo->sensor_drv_version = CONFIG_SENSOR_DRV_VERSION;
	
    *pdata = pSensorI2cInfo;
    return RET_SUCCESS;
}

/******************************************************************************
 * See header file for detailed comment.
 *****************************************************************************/

/*****************************************************************************/
/**
 */
/*****************************************************************************/
IsiCamDrvConfig_t IsiCamDrvConfig =
{
    0,
    IMX322_IsiGetSensorIss,
    {
        0,                      /**< IsiSensor_t.pszName */
        0,                      /**< IsiSensor_t.pRegisterTable */
        0,                      /**< IsiSensor_t.pIsiSensorCaps */
        0,						/**< IsiSensor_t.pIsiGetSensorIsiVer_t>*/   //oyyf add
        0,                      /**< IsiSensor_t.pIsiGetSensorTuningXmlVersion_t>*/   //oyyf add 
        0,                      /**< IsiSensor_t.pIsiWhiteBalanceIlluminationChk>*/   //ddl@rock-chips.com 
        0,                      /**< IsiSensor_t.pIsiWhiteBalanceIlluminationSet>*/   //ddl@rock-chips.com
        0,                      /**< IsiSensor_t.pIsiCheckOTPInfo>*/  //zyc 
        0,                      /**< IsiSensor_t.pIsiCreateSensorIss */
        0,                      /**< IsiSensor_t.pIsiReleaseSensorIss */
        0,                      /**< IsiSensor_t.pIsiGetCapsIss */
        0,                      /**< IsiSensor_t.pIsiSetupSensorIss */
        0,                      /**< IsiSensor_t.pIsiChangeSensorResolutionIss */
        0,                      /**< IsiSensor_t.pIsiSensorSetStreamingIss */
        0,                      /**< IsiSensor_t.pIsiSensorSetPowerIss */
        0,                      /**< IsiSensor_t.pIsiCheckSensorConnectionIss */
        0,                      /**< IsiSensor_t.pIsiGetSensorRevisionIss */
        0,                      /**< IsiSensor_t.pIsiRegisterReadIss */
        0,                      /**< IsiSensor_t.pIsiRegisterWriteIss */

        0,                      /**< IsiSensor_t.pIsiExposureControlIss */
        0,                      /**< IsiSensor_t.pIsiGetGainLimitsIss */
        0,                      /**< IsiSensor_t.pIsiGetIntegrationTimeLimitsIss */
        0,                      /**< IsiSensor_t.pIsiGetCurrentExposureIss */
        0,                      /**< IsiSensor_t.pIsiGetGainIss */
        0,                      /**< IsiSensor_t.pIsiGetGainIncrementIss */
        0,                      /**< IsiSensor_t.pIsiSetGainIss */
        0,                      /**< IsiSensor_t.pIsiGetIntegrationTimeIss */
        0,                      /**< IsiSensor_t.pIsiGetIntegrationTimeIncrementIss */
        0,                      /**< IsiSensor_t.pIsiSetIntegrationTimeIss */
        0,                      /**< IsiSensor_t.pIsiGetResolutionIss */
        0,                      /**< IsiSensor_t.pIsiGetAfpsInfoIss */

        0,                      /**< IsiSensor_t.pIsiGetCalibKFactor */
        0,                      /**< IsiSensor_t.pIsiGetCalibPcaMatrix */
        0,                      /**< IsiSensor_t.pIsiGetCalibSvdMeanValue */
        0,                      /**< IsiSensor_t.pIsiGetCalibCenterLine */
        0,                      /**< IsiSensor_t.pIsiGetCalibClipParam */
        0,                      /**< IsiSensor_t.pIsiGetCalibGlobalFadeParam */
        0,                      /**< IsiSensor_t.pIsiGetCalibFadeParam */
        0,                      /**< IsiSensor_t.pIsiGetIlluProfile */
        0,                      /**< IsiSensor_t.pIsiGetLscMatrixTable */

        0,                      /**< IsiSensor_t.pIsiMdiInitMotoDriveMds */
        0,                      /**< IsiSensor_t.pIsiMdiSetupMotoDrive */
        0,                      /**< IsiSensor_t.pIsiMdiFocusSet */
        0,                      /**< IsiSensor_t.pIsiMdiFocusGet */
        0,                      /**< IsiSensor_t.pIsiMdiFocusCalibrate */

        0,                      /**< IsiSensor_t.pIsiGetSensorMipiInfoIss */

        0,                      /**< IsiSensor_t.pIsiActivateTestPattern */
    },
    IMX322_IsiGetSensorI2cInfo,
};



