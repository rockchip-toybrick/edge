/*
 * Copyright (C) 2016 Rockchip Electronics Co.Ltd
 * Authors:
 *	Zhiqin Wei <wzq@rock-chips.com>
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 */

#define LOG_NDEBUG 0
#define LOG_TAG "rgaBlit"

#include <stdint.h>
#include <sys/types.h>
#include <math.h>
#include <fcntl.h>
#include <utils/misc.h>
#include <signal.h>
#include <time.h>

#include <cutils/properties.h>

#ifndef ANDROID_8

#include <binder/IPCThreadState.h>

#endif
#include <utils/Atomic.h>
#include <utils/Errors.h>
#include <utils/Log.h>

#include <ui/PixelFormat.h>
#include <ui/Rect.h>
#include <ui/Region.h>
#include <ui/DisplayInfo.h>
#include <ui/GraphicBufferMapper.h>
#include <RockchipRga.h>

#include <gui/ISurfaceComposer.h>

#include <GLES/gl.h>
#include <GLES/glext.h>
#include <EGL/eglext.h>

#include <stdint.h>
#include <sys/types.h>

//#include <system/window.h>

#include <utils/Thread.h>

#include <EGL/egl.h>
#include <GLES/gl.h>

///////////////////////////////////////////////////////
//#include "../drmrga.h"
#include <hardware/hardware.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>

#include <sys/mman.h>
#include <linux/stddef.h>
#include "RockchipFileOps.h"
///////////////////////////////////////////////////////

using namespace android;

int NormalRgaSetColorFillMode(
        struct rga_req *msg,                COLOR_FILL  *gr_color,
        unsigned char  gr_satur_mode,       unsigned char  cf_mode,
        unsigned int color,                 unsigned short pat_width,
        unsigned short pat_height,          unsigned char pat_x_off,
        unsigned char pat_y_off,            unsigned char aa_en)
{
    msg->render_mode = color_fill_mode;

    msg->gr_color.gr_x_a = ((int)(gr_color->gr_x_a * 256.0))& 0xffff;
    msg->gr_color.gr_x_b = ((int)(gr_color->gr_x_b * 256.0))& 0xffff;
    msg->gr_color.gr_x_g = ((int)(gr_color->gr_x_g * 256.0))& 0xffff;
    msg->gr_color.gr_x_r = ((int)(gr_color->gr_x_r * 256.0))& 0xffff;

    msg->gr_color.gr_y_a = ((int)(gr_color->gr_y_a * 256.0))& 0xffff;
    msg->gr_color.gr_y_b = ((int)(gr_color->gr_y_b * 256.0))& 0xffff;
    msg->gr_color.gr_y_g = ((int)(gr_color->gr_y_g * 256.0))& 0xffff;
    msg->gr_color.gr_y_r = ((int)(gr_color->gr_y_r * 256.0))& 0xffff;

    msg->color_fill_mode = cf_mode;

    msg->pat.act_w = pat_width;
    msg->pat.act_h = pat_height;

    msg->pat.x_offset = pat_x_off;
    msg->pat.y_offset = pat_y_off;

    msg->fg_color = color;

    msg->alpha_rop_flag |= ((gr_satur_mode & 1) << 6);

    if(aa_en)
    {
        msg->alpha_rop_flag |= 0x1;
        msg->alpha_rop_mode  = 1;
    }
    return 1;
}

static int rgaColorFill(sp<GraphicBuffer>&dst_buf, int dstfd, int color)
{
    int fd = -1;
    struct rga_req rgaReg;
    int ret = 0;
	COLOR_FILL fillColor;

    printf("rk-debug run rga");
    //init
    fd = open("/dev/rga", O_RDWR, 0);
    if (fd < 0) {
        ret = -ENODEV;
        ALOGE("fucking failed to open rga:%s.", strerror(errno));
        return 0;
    }

    memset(&rgaReg, 0, sizeof(struct rga_req));

	rgaReg.dst.format = RK_FORMAT_RGBA_8888;

	rgaReg.dst.vir_w = dst_buf->getWidth();
	rgaReg.dst.vir_h = dst_buf->getHeight();
	rgaReg.dst.act_w = dst_buf->getWidth();
	rgaReg.dst.act_h = dst_buf->getHeight();
	rgaReg.dst.x_offset = 0;
	rgaReg.dst.y_offset = 0;

	rgaReg.mmu_info.mmu_en = 1;
    rgaReg.mmu_info.mmu_flag = ((2 & 0x3) << 4) | 1 | (1 << 31 | 1 << 8 | 1 << 10);

	rgaReg.dst.yrgb_addr = dstfd;//hnd_dst->fd[0]; //(unsigned int)dst;
    rgaReg.dst.uv_addr = 0;//(long)dst;
    rgaReg.dst.v_addr   = 0;

	memset(&fillColor , 0x0, sizeof(COLOR_FILL));

	NormalRgaSetColorFillMode(&rgaReg, &fillColor, 0, 0, color, 0, 0, 0, 0, 0);

	if(ioctl(fd, RGA_BLIT_SYNC, &rgaReg)) {
        printf(" %s(%d) RGA_BLIT fail: %s",__FUNCTION__, __LINE__,strerror(errno));
        ALOGE(" %s(%d) RGA_BLIT fail: %s",__FUNCTION__, __LINE__,strerror(errno));
		return -errno;
    }

	close(fd);
    return 0;
}

int main()
{
    int ret = 0;
    int dstWidth,dstHeight,dstFormat;
    char* buf = NULL;


    dstWidth = 1280;
    dstHeight = 720;
	dstFormat = HAL_PIXEL_FORMAT_RGBA_8888;
	
	/********** instantiation RockchipRga **********/
    RockchipRga& rkRga(RockchipRga::get());
	
	/********** instantiation GraphicBufferMapper **********/
//    GraphicBufferMapper &mgbMapper = GraphicBufferMapper::get();
        
	/********** apply for dst_buffer **********/
#ifdef ANDROID_7_DRM
    sp<GraphicBuffer> gbd(new GraphicBuffer(dstWidth,dstHeight,dstFormat,
        GRALLOC_USAGE_SW_WRITE_OFTEN | GRALLOC_USAGE_SW_READ_OFTEN | GRALLOC_USAGE_HW_FB));
#else
    sp<GraphicBuffer> gbd(new GraphicBuffer(dstWidth,dstHeight,dstFormat,
        GRALLOC_USAGE_SW_WRITE_OFTEN | GRALLOC_USAGE_SW_READ_OFTEN));
#endif

    if (gbd->initCheck()) {
        printf("GraphicBuffer_dst error : %s\n",strerror(errno));
        return ret;
    } else
        printf("GraphicBuffer_dst %s \n","ok");

    /********** map buffer_address to userspace **********/
/*
#ifdef ANDROID_8
    buffer_handle_t importedHandle_dst;
    mgbMapper.importBuffer(gbd->handle, &importedHandle_dst);
    gbd->handle = importedHandle_dst;
#else
    mgbMapper.registerBuffer(gbd->handle);
#endif
*/
	/********** write data to src_buffer or init buffer**********/
    ret = gbd->lock(GRALLOC_USAGE_SW_WRITE_OFTEN, (void**)&buf);
    if (ret) {
        printf("lock buffer_dst error : %s\n",strerror(errno));
        return ret;
    } else 
        printf("lock buffer_dst %s \n","ok");


    memset(buf,0x00,4*1280*720);


    ret = gbd->unlock();
    if (ret) {
        printf("unlock buffer_dst error : %s\n",strerror(errno));
        return ret;
    } else 
        printf("unlock buffer_dst %s \n","ok");

	int dstfd;

        /******************************
         * Get Dst_fd:
         * Calling RkRgaGetBufferFd interface of rkRga to get fd by handle
         ******************************/
        ret = rkRga.RkRgaGetBufferFd(gbd->handle, &dstfd);
        printf("dst.fd =%d \n",dstfd);
        if (ret) {
            printf("rgaGetdstFd error : %s,hnd=%p\n",
                                            strerror(errno),(void*)(gbd->handle));
        }

	rgaColorFill(gbd, dstfd, 0xff00ff00);

	{
		/********** output buf data to file **********/
        char* dstbuf = NULL;
        ret = gbd->lock(GRALLOC_USAGE_SW_WRITE_OFTEN, (void**)&dstbuf);
        output_buf_data_to_file(dstbuf, dstFormat, dstWidth, dstHeight, 0);
        ret = gbd->unlock();
    }

    return 0;
}
