## ioctl RGA 说明

目前提供两个demo

rgaBlit ：提供缩放以及旋转功能

rgaColorFill ：单色填充功能 

我这边验证仍然以librga 为编译基础，如果没有Android编译请直接拷贝出两个demo 中以下函数，单独放到其他地方编译验证。针对不同情况，需要自行修改或者添加参数。

```
rgaCopyBit(sp<GraphicBuffer>&src_buf,  sp<GraphicBuffer>&dst_buf,  int srcfd,  int dstfd,  int rotation)
```

```
rgaColorFill(sp<GraphicBuffer>&dst_buf, int dstfd, int color)
```

这里传入的GraphicBuffer 为Android 特有，申请的buf的。其他非Android，请修改为直接传入buffer 的宽高，offset，stride 等参数。并修改函数内相关的逻辑。

原先的dst 以及src 效果的以下成员

```
vir_w = dst_buf->getWidth();
vir_h = dst_buf->getHeight();
act_w = dst_buf->getWidth();
act_h = dst_buf->getHeight();
x_offset = 0;
y_offset = 0;
```

请修改为外部传入的的参数

```
vir_w = stride_width;
vir_h = stride_height;
act_w = act_width;
act_h = act_height;
x_offset = xoffset;
y_offset = yoffset;
```



srcfd、dstfd 为 需要操作的buffer 的fd。

如果传入的为虚拟地址(void *src, void *dst)，请将

```
rgaReg.src.yrgb_addr = srcfd;
rgaReg.src.uv_addr  = 0;
rgaReg.dst.yrgb_addr = dstfd;
rgaReg.dst.uv_addr = 0;
```

修改为

```
rgaReg.src.yrgb_addr = 0;
rgaReg.src.uv_addr  = src;
rgaReg.dst.yrgb_addr = 0;
rgaReg.dst.uv_addr = dst;
```



rotation 为旋转参数，配置参数为：

```
HAL_TRANSFORM_FLIP_H
HAL_TRANSFORM_FLIP_V
HAL_TRANSFORM_ROT_90
HAL_TRANSFORM_ROT_180
HAL_TRANSFORM_ROT_270
```

color 为需要填充的颜色设置。

缩放功能直接将dst 实际宽高配置为需要的参数即可。



## rgaReg 部分变量说明

src format：

```
rgaReg.src.format
```

dst format：

```
rgaReg.dst.format
```

旋转模式。0 对应默认拷贝场景，1 对应普通角度旋转，2 对应水平垂直翻转。

```
rgaReg.rotate_mode
```

虚宽，虚高：

```
rgaReg.src.vir_w
rgaReg.src.vir_h
rgaReg.dst.vir_w
rgaReg.dst.vir_h
```

实际宽高：

```
rgaReg.src.act_w
rgaReg.src.act_h
rgaReg.dst.act_w
rgaReg.dst.act_h
```

偏移

```
rgaReg.src.x_offset
rgaReg.src.y_offset
rgaReg.dst.x_offset
rgaReg.dst.y_offset
```

旋转角度，需要和旋转模式 1 配合，需要查表。参考demo 中sina_table以及cosa_table

```
rgaReg.sina
rgaReg.cosa
```

MMU 使能总开关

```
rgaReg.mmu_info.mmu_en
```

MMU flag （主要用于配置单独开关src或者dst的mmu）

```
rgaReg.mmu_info.mmu_flag
```

缩放模式

```
rgaReg.scale_mode
```

fd 以及物理地址 配置

```
rgaReg.src.yrgb_addr
```

虚地址配置

```
rgaReg.src.uv_addr
```

渲染模式，目前仅使用bitblt_mode 以及color_fill_mode

```
rgaReg.render_mode
```

