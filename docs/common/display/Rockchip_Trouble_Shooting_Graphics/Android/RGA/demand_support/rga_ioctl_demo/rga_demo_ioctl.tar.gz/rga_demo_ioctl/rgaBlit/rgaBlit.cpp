/*
 * Copyright (C) 2016 Rockchip Electronics Co.Ltd
 * Authors:
 *	Zhiqin Wei <wzq@rock-chips.com>
 *
 * This program is free software; you can redistribute  it and/or modify it
 * under  the terms of  the GNU General  Public License as published by the
 * Free Software Foundation;  either version 2 of the  License, or (at your
 * option) any later version.
 *
 */

#define LOG_NDEBUG 0
#define LOG_TAG "rgaBlit"

#include <stdint.h>
#include <sys/types.h>
#include <math.h>
#include <fcntl.h>
#include <utils/misc.h>
#include <signal.h>
#include <time.h>

#include <cutils/properties.h>

#ifndef ANDROID_8

#include <binder/IPCThreadState.h>

#endif
#include <utils/Atomic.h>
#include <utils/Errors.h>
#include <utils/Log.h>

#include <ui/PixelFormat.h>
#include <ui/Rect.h>
#include <ui/Region.h>
#include <ui/DisplayInfo.h>
#include <ui/GraphicBufferMapper.h>
#include <RockchipRga.h>

#include <gui/ISurfaceComposer.h>

#include <GLES/gl.h>
#include <GLES/glext.h>
#include <EGL/eglext.h>

#include <stdint.h>
#include <sys/types.h>

//#include <system/window.h>

#include <utils/Thread.h>

#include <EGL/egl.h>
#include <GLES/gl.h>

///////////////////////////////////////////////////////
//#include "../drmrga.h"
#include <hardware/hardware.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>

#include <sys/mman.h>
#include <linux/stddef.h>
#include "RockchipFileOps.h"
///////////////////////////////////////////////////////

#define RGA_BUF_GEM_TYPE_DMA       0x80

static int sina_table[360] = 
{
     0,   1144,   2287,   3430,   4572,   5712,   6850,   7987,   9121,  10252,
 11380,  12505,  13626,  14742,  15855,  16962,  18064,  19161,  20252,  21336,
 22415,  23486,  24550,  25607,  26656,  27697,  28729,  29753,  30767,  31772,
 32768,  33754,  34729,  35693,  36647,  37590,  38521,  39441,  40348,  41243,
 42126,  42995,  43852,  44695,  45525,  46341,  47143,  47930,  48703,  49461,
 50203,  50931,  51643,  52339,  53020,  53684,  54332,  54963,  55578,  56175,
 56756,  57319,  57865,  58393,  58903,  59396,  59870,  60326,  60764,  61183,
 61584,  61966,  62328,  62672,  62997,  63303,  63589,  63856,  64104,  64332,
 64540,  64729,  64898,  65048,  65177,  65287,  65376,  65446,  65496,  65526,
 65536,  65526,  65496,  65446,  65376,  65287,  65177,  65048,  64898,  64729,
 64540,  64332,  64104,  63856,  63589,  63303,  62997,  62672,  62328,  61966,
 61584,  61183,  60764,  60326,  59870,  59396,  58903,  58393,  57865,  57319,
 56756,  56175,  55578,  54963,  54332,  53684,  53020,  52339,  51643,  50931,
 50203,  49461,  48703,  47930,  47143,  46341,  45525,  44695,  43852,  42995,
 42126,  41243,  40348,  39441,  38521,  37590,  36647,  35693,  34729,  33754,
 32768,  31772,  30767,  29753,  28729,  27697,  26656,  25607,  24550,  23486,
 22415,  21336,  20252,  19161,  18064,  16962,  15855,  14742,  13626,  12505,
 11380,  10252,   9121,   7987,   6850,   5712,   4572,   3430,   2287,   1144,
     0,  -1144,  -2287,  -3430,  -4572,  -5712,  -6850,  -7987,  -9121, -10252,
-11380, -12505, -13626, -14742, -15855, -16962, -18064, -19161, -20252, -21336,
-22415, -23486, -24550, -25607, -26656, -27697, -28729, -29753, -30767, -31772,
-32768, -33754, -34729, -35693, -36647, -37590, -38521, -39441, -40348, -41243,
-42126, -42995, -43852, -44695, -45525, -46341, -47143, -47930, -48703, -49461,
-50203, -50931, -51643, -52339, -53020, -53684, -54332, -54963, -55578, -56175,
-56756, -57319, -57865, -58393, -58903, -59396, -59870, -60326, -60764, -61183,
-61584, -61966, -62328, -62672, -62997, -63303, -63589, -63856, -64104, -64332,
-64540, -64729, -64898, -65048, -65177, -65287, -65376, -65446, -65496, -65526,
-65536, -65526, -65496, -65446, -65376, -65287, -65177, -65048, -64898, -64729,
-64540, -64332, -64104, -63856, -63589, -63303, -62997, -62672, -62328, -61966,
-61584, -61183, -60764, -60326, -59870, -59396, -58903, -58393, -57865, -57319,
-56756, -56175, -55578, -54963, -54332, -53684, -53020, -52339, -51643, -50931,
-50203, -49461, -48703, -47930, -47143, -46341, -45525, -44695, -43852, -42995,
-42126, -41243, -40348, -39441, -38521, -37590, -36647, -35693, -34729, -33754,
-32768, -31772, -30767, -29753, -28729, -27697, -26656, -25607, -24550, -23486, 
-22415, -21336, -20252, -19161, -18064, -16962, -15855, -14742, -13626, -12505,
-11380, -10252, -9121,   -7987,  -6850,  -5712,  -4572,  -3430,  -2287,  -1144
};

static int cosa_table[360] = 
{
 65536,  65526,  65496,  65446,  65376,  65287,  65177,  65048,  64898,  64729,
 64540,  64332,  64104,  63856,  63589,  63303,  62997,  62672,  62328,  61966,
 61584,  61183,  60764,  60326,  59870,  59396,  58903,  58393,  57865,  57319,
 56756,  56175,  55578,  54963,  54332,  53684,  53020,  52339,  51643,  50931,
 50203,  49461,  48703,  47930,  47143,  46341,  45525,  44695,  43852,  42995,
 42126,  41243,  40348,  39441,  38521,  37590,  36647,  35693,  34729,  33754,
 32768,  31772,  30767,  29753,  28729,  27697,  26656,  25607,  24550,  23486,
 22415,  21336,  20252,  19161,  18064,  16962,  15855,  14742,  13626,  12505,
 11380,  10252,   9121,   7987,   6850,   5712,   4572,   3430,   2287,   1144,
     0,  -1144,  -2287,  -3430,  -4572,  -5712,  -6850,  -7987,  -9121, -10252,
-11380, -12505, -13626, -14742, -15855, -16962, -18064, -19161, -20252, -21336,
-22415, -23486, -24550, -25607, -26656, -27697, -28729, -29753, -30767, -31772,
-32768, -33754, -34729, -35693, -36647, -37590, -38521, -39441, -40348, -41243,
-42126, -42995, -43852, -44695, -45525, -46341, -47143, -47930, -48703, -49461,
-50203, -50931, -51643, -52339, -53020, -53684, -54332, -54963, -55578, -56175,
-56756, -57319, -57865, -58393, -58903, -59396, -59870, -60326, -60764, -61183,
-61584, -61966, -62328, -62672, -62997, -63303, -63589, -63856, -64104, -64332,
-64540, -64729, -64898, -65048, -65177, -65287, -65376, -65446, -65496, -65526,
-65536, -65526, -65496, -65446, -65376, -65287, -65177, -65048, -64898, -64729,
-64540, -64332, -64104, -63856, -63589, -63303, -62997, -62672, -62328, -61966,
-61584, -61183, -60764, -60326, -59870, -59396, -58903, -58393, -57865, -57319,
-56756, -56175, -55578, -54963, -54332, -53684, -53020, -52339, -51643, -50931,
-50203, -49461, -48703, -47930, -47143, -46341, -45525, -44695, -43852, -42995,
-42126, -41243, -40348, -39441, -38521, -37590, -36647, -35693, -34729, -33754,
-32768, -31772, -30767, -29753, -28729, -27697, -26656, -25607, -24550, -23486,
-22415, -21336, -20252, -19161, -18064, -16962, -15855, -14742, -13626, -12505,
-11380, -10252,  -9121,  -7987,  -6850,  -5712,  -4572,  -3430,  -2287,  -1144,
     0,   1144,   2287,   3430,   4572,   5712,   6850,   7987,   9121,  10252,
 11380,  12505,  13626,  14742,  15855,  16962,  18064,  19161,  20252,  21336,
 22415,  23486,  24550,  25607,  26656,  27697,  28729,  29753,  30767,  31772,
 32768,  33754,  34729,  35693,  36647,  37590,  38521,  39441,  40348,  41243,
 42126,  42995,  43852,  44695,  45525,  46341,  47143,  47930,  48703,  49461,
 50203,  50931,  51643,  52339,  53020,  53684,  54332,  54963,  55578,  56175,
 56756,  57319,  57865,  58393,  58903,  59396,  59870,  60326,  60764,  61183,
 61584,  61966,  62328,  62672,  62997,  63303,  63589,  63856,  64104,  64332,
 64540,  64729,  64898,  65048,  65177,  65287,  65376,  65446,  65496,  65526
};

using namespace android;

static int rgaCopyBit(sp<GraphicBuffer>&src_buf, sp<GraphicBuffer>&dst_buf, int srcfd, int dstfd, int rotation)//char* src, char* dst)
{
    int fd = -1;
    struct rga_req rgaReg;
    int ret = 0;

    printf("rk-debug run rga");
    //init
    fd = open("/dev/rga", O_RDWR, 0);
    if (fd < 0) {
        ret = -ENODEV;
        ALOGE("fucking failed to open rga:%s.", strerror(errno));
        return 0;
    }

    memset(&rgaReg, 0, sizeof(struct rga_req));

    rgaReg.src.format = RK_FORMAT_RGBA_8888;//RK_FORMAT_RGBA_8888;  RK_FORMAT_YCbCr_420_SP;                                                                                       
    rgaReg.dst.format = RK_FORMAT_RGBA_8888;                                                                                     

    switch (rotation) {
        case HAL_TRANSFORM_FLIP_H:
			rgaReg.rotate_mode = 2;

			rgaReg.src.vir_w = src_buf->getWidth();
			rgaReg.src.vir_h = src_buf->getHeight();
			rgaReg.src.x_offset = 0;
			rgaReg.src.y_offset = 0;
			rgaReg.src.act_w = src_buf->getWidth();
			rgaReg.src.act_h = src_buf->getHeight();

			rgaReg.dst.vir_w = dst_buf->getWidth();
			rgaReg.dst.vir_h = dst_buf->getHeight();
			rgaReg.dst.act_w = dst_buf->getWidth();
			rgaReg.dst.act_h = dst_buf->getHeight();
			rgaReg.dst.x_offset = 0;
			rgaReg.dst.y_offset = 0;

            break;
        case HAL_TRANSFORM_FLIP_V:
			rgaReg.rotate_mode = 3;

			rgaReg.src.vir_w = src_buf->getWidth();
            rgaReg.src.vir_h = src_buf->getHeight();
            rgaReg.src.x_offset = 0;
            rgaReg.src.y_offset = 0;
            rgaReg.src.act_w = src_buf->getWidth();
            rgaReg.src.act_h = src_buf->getHeight();

            rgaReg.dst.vir_w = dst_buf->getWidth();
            rgaReg.dst.vir_h = dst_buf->getHeight();
            rgaReg.dst.act_w = dst_buf->getWidth();
            rgaReg.dst.act_h = dst_buf->getHeight();
            rgaReg.dst.x_offset = 0;
            rgaReg.dst.y_offset = 0;

            break;
		case HAL_TRANSFORM_ROT_90:
			rgaReg.sina = sina_table[90];
			rgaReg.cosa = cosa_table[90];
			
			rgaReg.rotate_mode = 1;            

			rgaReg.src.vir_w = src_buf->getWidth();
            rgaReg.src.vir_h = src_buf->getHeight();
            rgaReg.src.x_offset = 0;
            rgaReg.src.y_offset = 0;
            rgaReg.src.act_w = src_buf->getWidth();
            rgaReg.src.act_h = src_buf->getHeight();

            rgaReg.dst.vir_w = dst_buf->getWidth();
            rgaReg.dst.vir_h = dst_buf->getHeight();
            rgaReg.dst.x_offset = dst_buf->getWidth() - 1;
            //rgaReg.dst.y_offset = relDstRect.yoffset;
            rgaReg.dst.y_offset = 0;
			rgaReg.dst.act_w = dst_buf->getHeight();
            rgaReg.dst.act_h = dst_buf->getWidth();
            break;
        case HAL_TRANSFORM_ROT_180:
            rgaReg.sina = sina_table[180];
            rgaReg.cosa = cosa_table[180];
            rgaReg.rotate_mode = 1;

            rgaReg.src.vir_w = src_buf->getWidth();
            rgaReg.src.vir_h = src_buf->getHeight();
            rgaReg.src.x_offset = 0;
            rgaReg.src.y_offset = 0;
            rgaReg.src.act_w = src_buf->getWidth();
            rgaReg.src.act_h = src_buf->getHeight();

            rgaReg.dst.vir_w = dst_buf->getWidth();
            rgaReg.dst.vir_h = dst_buf->getHeight();
            rgaReg.dst.x_offset = dst_buf->getWidth() - 1;
            rgaReg.dst.y_offset = dst_buf->getHeight() - 1;
            rgaReg.dst.act_w = dst_buf->getWidth();
            rgaReg.dst.act_h = dst_buf->getHeight();
            break;
        case HAL_TRANSFORM_ROT_270:
            rgaReg.sina = sina_table[270];
            rgaReg.cosa = cosa_table[270];
            rgaReg.rotate_mode = 1;

            rgaReg.src.vir_w = src_buf->getWidth();
            rgaReg.src.vir_h = src_buf->getHeight();
            rgaReg.src.x_offset = 0;
            rgaReg.src.y_offset = 0;
            rgaReg.src.act_w = src_buf->getWidth();
            rgaReg.src.act_h = src_buf->getHeight();

            rgaReg.dst.vir_w = dst_buf->getWidth();
            rgaReg.dst.vir_h = dst_buf->getHeight();
            rgaReg.dst.x_offset = 0;
            rgaReg.dst.y_offset = dst_buf->getHeight() - 1;
            rgaReg.dst.act_w = dst_buf->getHeight();
            rgaReg.dst.act_h = dst_buf->getWidth();
            break;
		default:
			rgaReg.rotate_mode = 0;

			rgaReg.src.vir_w = src_buf->getWidth();
			rgaReg.src.vir_h = src_buf->getHeight();
			rgaReg.src.act_w = src_buf->getWidth();
			rgaReg.src.act_h = src_buf->getHeight();
			rgaReg.src.x_offset = 0;
			rgaReg.src.y_offset = 0;

			rgaReg.dst.vir_w = dst_buf->getWidth();
			rgaReg.dst.vir_h = dst_buf->getHeight();
			rgaReg.dst.act_w = dst_buf->getWidth();
			rgaReg.dst.act_h = dst_buf->getHeight();
			rgaReg.dst.x_offset = 0;
			rgaReg.dst.y_offset = 0;
			break;
	}		

    rgaReg.clip.xmin = 0;                                                                                           
    rgaReg.clip.xmax = dst_buf->getWidth() - 1;                                                                                      
    rgaReg.clip.ymin = 0;                                                                                           
    rgaReg.clip.ymax = dst_buf->getHeight() - 1;                                                                                      

    rgaReg.mmu_info.mmu_en = 1;                                                                                     
    rgaReg.mmu_info.mmu_flag = ((2 & 0x3) << 4) | 1 | (1 << 31 | 1 << 8 | 1 << 10);

    //native_handle_t* hnd_src = (native_handle_t*)(src_buf->handle);
    rgaReg.src.yrgb_addr = srcfd;//hnd_src->fd[0]; //(unsigned int)src;
    rgaReg.src.uv_addr  = 0;//(long)src;
    rgaReg.src.v_addr   = 0;

    //native_handle_t* hnd_dst = (native_handle_t*)(dst_buf->handle);
    rgaReg.dst.yrgb_addr = dstfd;//hnd_dst->fd[0]; //(unsigned int)dst;
    rgaReg.dst.uv_addr = 0;//(long)dst;
    rgaReg.dst.v_addr   = 0;

    rgaReg.scale_mode = 0;
    rgaReg.render_mode = bitblt_mode;

    ALOGE("rga render_mode=%d rotate_mode=%d, rga_fd = %d\n",
            rgaReg.render_mode, rgaReg.rotate_mode, fd);
    ALOGE("rga src:[%lx,%lx,%lx],x-y[%d,%d],w-h[%d,%d],vw-vh[%d,%d],f=%d",
            rgaReg.src.yrgb_addr, rgaReg.src.uv_addr, rgaReg.src.v_addr,
            rgaReg.src.x_offset, rgaReg.src.y_offset,
            rgaReg.src.act_w, rgaReg.src.act_h,
            rgaReg.src.vir_w, rgaReg.src.vir_h, rgaReg.src.format);
    ALOGE("rga dst:[%lx,%lx,%lx],x-y[%d,%d],w-h[%d,%d],vw-vh[%d,%d],f=%d",
            rgaReg.dst.yrgb_addr, rgaReg.dst.uv_addr, rgaReg.dst.v_addr,
            rgaReg.dst.x_offset, rgaReg.dst.y_offset,
            rgaReg.dst.act_w, rgaReg.dst.act_h,
            rgaReg.dst.vir_w, rgaReg.dst.vir_h, rgaReg.dst.format);
    ALOGE("rga pat:[%lx,%lx,%lx],x-y[%d,%d],w-h[%d,%d],vw-vh[%d,%d],f=%d",
            rgaReg.pat.yrgb_addr, rgaReg.pat.uv_addr, rgaReg.pat.v_addr,
            rgaReg.pat.x_offset, rgaReg.pat.y_offset,
            rgaReg.pat.act_w, rgaReg.pat.act_h,
            rgaReg.pat.vir_w, rgaReg.pat.vir_h, rgaReg.pat.format);
    ALOGE("rga ROP:[%lx,%hx,%hx],LUT[%lx]", rgaReg.rop_mask_addr, rgaReg.alpha_rop_flag,
            rgaReg.rop_code, rgaReg.LUT_addr);

    //ALOGE("rga color:[%x,%x,%lx,%lx,%hx]", rgaReg.color_key_max, rgaReg.color_key_min,
    //        rgaReg.fg_color, rgaReg.bg_color, rgaReg.color_fill_mode);

    ALOGE("rga MMU:[%d,%lx,%x]", rgaReg.mmu_info.mmu_en,
            rgaReg.mmu_info.base_addr, rgaReg.mmu_info.mmu_flag);


    ALOGE("rga mode[%d,%d,%d,%d,%d]", rgaReg.palette_mode, rgaReg.yuv2rgb_mode,
            rgaReg.endian_mode, rgaReg.src_trans_mode,rgaReg.scale_mode);
    

    if(ioctl(fd, RGA_BLIT_SYNC, &rgaReg)) {
        ALOGE("fucking failed to use rga(%s:%d):%s.", __func__, __LINE__, strerror(errno));
        return -errno;
    }
    close(fd);
    return 0;
}

int main()
{
    /******************************
     * Define Variable:
     * Define variable to describe the frame
     *******************************/
    int ret = 0;
    int srcWidth,srcHeight,srcFormat;
    int dstWidth,dstHeight,dstFormat;
    char* buf = NULL;

    /******************************
     * Initialize variable:
     * Set up variable according to requirements
     ******************************/
    srcWidth = 1280;
    srcHeight = 720;
    srcFormat = HAL_PIXEL_FORMAT_RGBA_8888;

    dstWidth = 1280;
    dstHeight = 720;
    dstFormat = HAL_PIXEL_FORMAT_RGBA_8888;
	
    /******************************
     * Instantiation RockchipRga:
     * Singleton pattern instantiates an interface,you can use it to call RGA_interface
     ******************************/
    RockchipRga& rkRga(RockchipRga::get());
	
    /******************************
     * Instantiation GraphicBufferMapper:
     * Instantiation Android's tool of GraphicBufferMapper,
     * It provides a mapping of buffer address into a user's address space
     ******************************/
//    GraphicBufferMapper &mgbMapper = GraphicBufferMapper::get();

    /******************************
     * Apply For Src_buffer:
     ******************************/
#ifdef ANDROID_7_DRM
    sp<GraphicBuffer> gbs(new GraphicBuffer(srcWidth,srcHeight,srcFormat,
        GRALLOC_USAGE_SW_WRITE_OFTEN | GRALLOC_USAGE_SW_READ_OFTEN | GRALLOC_USAGE_HW_FB));
#else
    sp<GraphicBuffer> gbs(new GraphicBuffer(srcWidth,srcHeight,srcFormat,
        GRALLOC_USAGE_SW_WRITE_OFTEN | GRALLOC_USAGE_SW_READ_OFTEN));
#endif

    if (gbs->initCheck()) {
        printf("GraphicBuffer_src error : %s\n",strerror(errno));
        return ret;
    }else{
        printf("GraphicBuffer_src %s \n","ok");
	}
        
    /******************************
     * Apply For Dst_buffer:
     ******************************/
#ifdef ANDROID_7_DRM
    sp<GraphicBuffer> gbd(new GraphicBuffer(dstWidth,dstHeight,dstFormat,
        GRALLOC_USAGE_SW_WRITE_OFTEN | GRALLOC_USAGE_SW_READ_OFTEN | GRALLOC_USAGE_HW_FB));
#else
    sp<GraphicBuffer> gbd(new GraphicBuffer(dstWidth,dstHeight,dstFormat,
        GRALLOC_USAGE_SW_WRITE_OFTEN | GRALLOC_USAGE_SW_READ_OFTEN));
#endif
    /******************************
     * Validity Check:
     ******************************/
    if (gbd->initCheck()) {
        printf("GraphicBuffer_dst error : %s\n",strerror(errno));
        return ret;
    } else
        printf("GraphicBuffer_dst %s \n","ok");

    /******************************
     * Map Buffer_address To Userspace:
     ******************************/
/*
#ifdef ANDROID_8
    buffer_handle_t importedHandle_src;
    buffer_handle_t importedHandle_dst;
    mgbMapper.importBuffer(gbs->handle, &importedHandle_src);
    mgbMapper.importBuffer(gbd->handle, &importedHandle_dst);
    gbs->handle = importedHandle_src;
    gbd->handle = importedHandle_dst;
#else
    mgbMapper.registerBuffer(gbs->handle);
    mgbMapper.registerBuffer(gbd->handle);
#endif
*/
    /******************************
     * Lock Src_buffer:
     ******************************/
    ret = gbs->lock(GRALLOC_USAGE_SW_WRITE_OFTEN, (void**)&buf);
    if (ret) {
        printf("lock buffer_src error : %s\n",strerror(errno));
        return ret;
    } else 
        printf("lock buffer_src %s \n","ok");

    /******************************
     * Write Data To Src_buffer:
     ******************************/
    get_buf_from_file(buf, srcFormat, srcWidth, srcHeight, 1);

    /******************************
     * Unlock Src_buffer:
     * You shoud immediately unlock when you have operated buffer.If you don't ,maybe cause memory leaks.
     ******************************/
    ret = gbs->unlock();
    if (ret) {
        printf("unlock buffer_src error : %s\n",strerror(errno));
        return ret;
    } else 
        printf("unlock buffer_src %s \n","ok");

    /******************************
     * Lock Dst_buffer:
     ******************************/
    ret = gbd->lock(GRALLOC_USAGE_SW_WRITE_OFTEN, (void**)&buf);
    if (ret) {
        printf("lock buffer_dst error : %s\n",strerror(errno));
        return ret;
    } else 
        printf("lock buffer_dst %s \n","ok");

    /******************************
     * Write Data To Dst_buffer:
     ******************************/
    //get_buf_from_file(buf, dstFormat, dstWidth, dstHeight, 0);

    /******************************
     * Unlock Dst_buffer:
     * You shoud immediately unlock when you have operated buffer.If you don't ,maybe cause memory leaks.
     ******************************/
    ret = gbd->unlock();
    if (ret) {
        printf("unlock buffer_src error : %s\n",strerror(errno));
        return ret;
    } else 
        printf("unlock buffer_src %s \n","ok");

	int srcfd, dstfd;

		/******************************
         * Get Src_fd:
         * Calling RkRgaGetBufferFd interface of rkRga to get fd by handle
         ******************************/
        ret = rkRga.RkRgaGetBufferFd(gbs->handle, &srcfd);
        printf("src.fd =%d\n",srcfd);
        if (ret) {
            printf("rgaGetsrcFd fail : %s,hnd=%p \n",
                                            strerror(errno),(void*)(gbd->handle));
        }
        /******************************
         * Get Dst_fd:
         * Calling RkRgaGetBufferFd interface of rkRga to get fd by handle
         ******************************/
        ret = rkRga.RkRgaGetBufferFd(gbd->handle, &dstfd);
        printf("dst.fd =%d \n",dstfd);
        if (ret) {
            printf("rgaGetdstFd error : %s,hnd=%p\n",
                                            strerror(errno),(void*)(gbd->handle));
        }

		/* set rotation */
		int rotation = HAL_TRANSFORM_ROT_180;
		//int rotation = HAL_TRANSFORM_FLIP_V;

		/* ioctl rga */
		rgaCopyBit(gbs, gbd, srcfd, dstfd, rotation);

	    /******************************
		 * Output Buf_data To File:
         * Print out the output as a file , can use 7YUV to check.
         ******************************/
        char* dstbuf = NULL;
        ret = gbd->lock(GRALLOC_USAGE_SW_WRITE_OFTEN, (void**)&dstbuf);
        output_buf_data_to_file(dstbuf, dstFormat, dstWidth, dstHeight, 0);
        ret = gbd->unlock();

		return 0;
}
