#ifndef _rk_graphics_version_h_
#define _rk_graphics_version_h_

#define RK_GRAPHICS_VER "version:8f47339+2019-09-24 10:45:06"

#endif // VERSION_H
