#ifndef _rk_graphics_version_h_
#define _rk_graphics_version_h_

#define RK_GRAPHICS_VER "version:7fee6bf+2019-12-16 16:48:19"

#endif // VERSION_H
