#ifndef SF_GLES20RENDERENGINE_KEYSTONE_H_
#define SF_GLES20RENDERENGINE_KEYSTONE_H_

typedef unsigned int uint32_t;

#include <stdint.h>
#include <sys/types.h>

#include <GLES2/gl2.h>

#include "../RenderEngine/ProgramCache.h"

// ---------------------------------------------------------------------------
namespace android {
// ---------------------------------------------------------------------------

class String8;
namespace RE {
namespace impl {
class Keystone {

public:
    Keystone();
    virtual ~Keystone();

    bool isNeedKeystone(int32_t displayType, int32_t displayId);
    int setTargetDpyXY(int32_t displayType, int32_t displayId, int x, int y);
    void onBeginGroup(GLuint name, GLuint tname);
    void onEndGroup(GLuint texCoords, GLuint position);
    void setScreenSize(uint32_t w, uint32_t h);

    static String8 generateVertexShader(const ProgramCache::Key& needs);
    static String8 generateFragmentShader(const ProgramCache::Key& needs);

protected:

    struct MeshBuffer{
        GLuint bufferHandle;
        GLuint last_x;
        GLuint last_y;
        GLboolean reCompute;
    };

    uint8_t *maskBuffer;
    uint32_t maskBufferLen;
    GLuint masktname;

    GLboolean isFirstStart;
    GLboolean isGetPropOK;

    struct MeshBuffer mMeshData;

    vec2 mLeftTop;
    vec2 mLeftBottom;
    vec2 mRightTop;
    vec2 mRightBottom;

    uint32_t mMode;
    uint32_t mLastMode;

private:
    void initKeystone();
    bool getKeystoneProp();
    GLuint genKeystoneMeshBuffer(float width, float height, GLuint lastBuffer);
    GLuint genKeystoneMeshBufferModeSplitW(float width, float height, GLuint lastBuffer);
    GLuint genKeystoneMeshBufferModeSplitH(float width, float height, GLuint lastBuffer);
    uint8_t* getMaskTextureBuffer(GLuint width, GLuint heigh);
    GLuint genMaskTexture(GLuint width, GLuint heigh);

};

};};
// ---------------------------------------------------------------------------
}; // namespace android
// ---------------------------------------------------------------------------

#endif /* SF_GLES20RENDERENGINE_KEYSTONE_H_ */
