package com.rockchip.keystone.keystone;

public class Keystone {

    public static final int KEYSTONE_CORRECTION_STEP = 10;

    public static int expandTop() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopLeft.x -= KEYSTONE_CORRECTION_STEP;
        kv.vTopRight.x += KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int shrinkTop() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopLeft.x += KEYSTONE_CORRECTION_STEP;
        kv.vTopRight.x -= KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int expandBottom() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vBottomLeft.x -= KEYSTONE_CORRECTION_STEP;
        kv.vBottomRight.x += KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int shrinkBottom() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vBottomLeft.x += KEYSTONE_CORRECTION_STEP;
        kv.vBottomRight.x -= KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int expandLeft() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopLeft.y += KEYSTONE_CORRECTION_STEP;
        kv.vBottomLeft.y -= KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int shrinkLeft() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopLeft.y -= KEYSTONE_CORRECTION_STEP;
        kv.vBottomLeft.y += KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int expandRight() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopRight.y += KEYSTONE_CORRECTION_STEP;
        kv.vBottomRight.y -= KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int shrinkRight() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopRight.y -= KEYSTONE_CORRECTION_STEP;
        kv.vBottomRight.y += KEYSTONE_CORRECTION_STEP;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static KeystoneVertex getVertex() {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        return kv;
    }

    public static int adjustTopTo(int value) {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopLeft.x = value;
        kv.vTopRight.x = -value;
        kv.updateAllKeystoneVertex();
        return 0;
    }


    public static int adjustBottomTo(int value) {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vBottomLeft.x = value;
        kv.vBottomRight.x = -value;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int adjustLeftTo(int value) {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopLeft.y = value;
        kv.vBottomLeft.y = -value;
        kv.updateAllKeystoneVertex();
        return 0;
    }

    public static int adjustRightTo(int value) {
        KeystoneVertex kv = new KeystoneVertex();
        kv.getAllKeystoneVertex();
        kv.vTopRight.y = value;
        kv.vBottomRight.y = -value;
        kv.updateAllKeystoneVertex();
        return 0;
    }
}
