package com.rockchip.keystone.keystone;

public class Vertex {
    int x = 0;
    int y = 0;

    public Vertex(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public Vertex(String strVertex) {
        String v[] = strVertex.trim().split(",");
        if (v != null) {
            this.x = Integer.parseInt(v[0]);
            this.y = Integer.parseInt(v[1]);			
        }
    }

    @Override
    public String toString() {
        return x + "," + y;
    }
}
