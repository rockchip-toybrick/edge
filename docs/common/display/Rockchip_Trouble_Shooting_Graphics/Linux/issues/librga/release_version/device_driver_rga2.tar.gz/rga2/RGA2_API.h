/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __RGA_API_H__
#define __RGA_API_H__

#include "rga2_reg_info.h"
#include "rga2.h"

#define ENABLE      1
#define DISABLE     0



#endif
